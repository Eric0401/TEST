﻿namespace 專題2._0
{
    partial class AccountForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelAccount = new Label();
            panel1 = new Panel();
            btnPotato = new Button();
            btnCucumber = new Button();
            btnTomato = new Button();
            btnGreenOnion = new Button();
            btnHoney = new Button();
            btnGarlic = new Button();
            btnSpinach = new Button();
            btnSoybean = new Button();
            btnPorkBlood = new Button();
            btnKelp = new Button();
            btnOrange = new Button();
            btnMilk = new Button();
            btnBanana = new Button();
            btnCarrot = new Button();
            btnApple = new Button();
            listBox1 = new ListBox();
            textBox1 = new TextBox();
            buttonSearch = new Button();
            buttonProvide = new Button();
            buttonSignout = new Button();
            panel1.SuspendLayout();
            SuspendLayout();
            // 
            // labelAccount
            // 
            labelAccount.AutoSize = true;
            labelAccount.Font = new Font("Microsoft JhengHei UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            labelAccount.Location = new Point(89, 62);
            labelAccount.Name = "labelAccount";
            labelAccount.Size = new Size(103, 35);
            labelAccount.TabIndex = 0;
            labelAccount.Text = "帳號： ";
            // 
            // panel1
            // 
            panel1.AutoScroll = true;
            panel1.BackColor = Color.White;
            panel1.Controls.Add(btnPotato);
            panel1.Controls.Add(btnCucumber);
            panel1.Controls.Add(btnTomato);
            panel1.Controls.Add(btnGreenOnion);
            panel1.Controls.Add(btnHoney);
            panel1.Controls.Add(btnGarlic);
            panel1.Controls.Add(btnSpinach);
            panel1.Controls.Add(btnSoybean);
            panel1.Controls.Add(btnPorkBlood);
            panel1.Controls.Add(btnKelp);
            panel1.Controls.Add(btnOrange);
            panel1.Controls.Add(btnMilk);
            panel1.Controls.Add(btnBanana);
            panel1.Controls.Add(btnCarrot);
            panel1.Controls.Add(btnApple);
            panel1.Location = new Point(95, 162);
            panel1.Name = "panel1";
            panel1.Size = new Size(370, 316);
            panel1.TabIndex = 1;
            // 
            // btnPotato
            // 
            btnPotato.Location = new Point(261, 445);
            btnPotato.Name = "btnPotato";
            btnPotato.Size = new Size(75, 75);
            btnPotato.TabIndex = 14;
            btnPotato.Text = "馬鈴薯";
            btnPotato.UseVisualStyleBackColor = true;
            // 
            // btnCucumber
            // 
            btnCucumber.Location = new Point(142, 445);
            btnCucumber.Name = "btnCucumber";
            btnCucumber.Size = new Size(75, 75);
            btnCucumber.TabIndex = 13;
            btnCucumber.Text = "黃瓜";
            btnCucumber.UseVisualStyleBackColor = true;
            // 
            // btnTomato
            // 
            btnTomato.Location = new Point(22, 445);
            btnTomato.Name = "btnTomato";
            btnTomato.Size = new Size(75, 75);
            btnTomato.TabIndex = 12;
            btnTomato.Text = "蕃茄";
            btnTomato.UseVisualStyleBackColor = true;
            // 
            // btnGreenOnion
            // 
            btnGreenOnion.Location = new Point(261, 339);
            btnGreenOnion.Name = "btnGreenOnion";
            btnGreenOnion.Size = new Size(75, 75);
            btnGreenOnion.TabIndex = 11;
            btnGreenOnion.Text = "大蔥";
            btnGreenOnion.UseVisualStyleBackColor = true;
            // 
            // btnHoney
            // 
            btnHoney.Location = new Point(142, 339);
            btnHoney.Name = "btnHoney";
            btnHoney.Size = new Size(75, 75);
            btnHoney.TabIndex = 10;
            btnHoney.Text = "蜂蜜";
            btnHoney.UseVisualStyleBackColor = true;
            // 
            // btnGarlic
            // 
            btnGarlic.Location = new Point(22, 339);
            btnGarlic.Name = "btnGarlic";
            btnGarlic.Size = new Size(75, 75);
            btnGarlic.TabIndex = 9;
            btnGarlic.Text = "大蒜";
            btnGarlic.UseVisualStyleBackColor = true;
            // 
            // btnSpinach
            // 
            btnSpinach.Location = new Point(261, 238);
            btnSpinach.Name = "btnSpinach";
            btnSpinach.Size = new Size(75, 75);
            btnSpinach.TabIndex = 8;
            btnSpinach.Text = "菠菜";
            btnSpinach.UseVisualStyleBackColor = true;
            // 
            // btnSoybean
            // 
            btnSoybean.Location = new Point(143, 238);
            btnSoybean.Name = "btnSoybean";
            btnSoybean.Size = new Size(75, 75);
            btnSoybean.TabIndex = 7;
            btnSoybean.Text = "黃豆";
            btnSoybean.UseVisualStyleBackColor = true;
            // 
            // btnPorkBlood
            // 
            btnPorkBlood.Location = new Point(22, 238);
            btnPorkBlood.Name = "btnPorkBlood";
            btnPorkBlood.Size = new Size(75, 75);
            btnPorkBlood.TabIndex = 6;
            btnPorkBlood.Text = "豬血";
            btnPorkBlood.UseVisualStyleBackColor = true;
            // 
            // btnKelp
            // 
            btnKelp.Location = new Point(261, 135);
            btnKelp.Name = "btnKelp";
            btnKelp.Size = new Size(75, 75);
            btnKelp.TabIndex = 5;
            btnKelp.Text = "海帶";
            btnKelp.UseVisualStyleBackColor = true;
            // 
            // btnOrange
            // 
            btnOrange.Location = new Point(143, 135);
            btnOrange.Name = "btnOrange";
            btnOrange.Size = new Size(75, 75);
            btnOrange.TabIndex = 4;
            btnOrange.Text = "橘子";
            btnOrange.UseVisualStyleBackColor = true;
            // 
            // btnMilk
            // 
            btnMilk.Location = new Point(22, 135);
            btnMilk.Name = "btnMilk";
            btnMilk.Size = new Size(75, 75);
            btnMilk.TabIndex = 3;
            btnMilk.Text = "牛奶";
            btnMilk.UseVisualStyleBackColor = true;
            // 
            // btnBanana
            // 
            btnBanana.Location = new Point(261, 35);
            btnBanana.Name = "btnBanana";
            btnBanana.Size = new Size(75, 75);
            btnBanana.TabIndex = 2;
            btnBanana.Text = "香蕉";
            btnBanana.UseVisualStyleBackColor = true;
            // 
            // btnCarrot
            // 
            btnCarrot.Location = new Point(143, 35);
            btnCarrot.Name = "btnCarrot";
            btnCarrot.Size = new Size(75, 75);
            btnCarrot.TabIndex = 1;
            btnCarrot.Text = "胡蘿蔔";
            btnCarrot.UseVisualStyleBackColor = true;
            // 
            // btnApple
            // 
            btnApple.Location = new Point(22, 35);
            btnApple.Name = "btnApple";
            btnApple.Size = new Size(75, 75);
            btnApple.TabIndex = 0;
            btnApple.Text = "蘋果";
            btnApple.UseVisualStyleBackColor = true;
            // 
            // listBox1
            // 
            listBox1.Font = new Font("Microsoft JhengHei UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            listBox1.FormattingEnabled = true;
            listBox1.ItemHeight = 24;
            listBox1.Location = new Point(518, 162);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(370, 316);
            listBox1.TabIndex = 2;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Microsoft JhengHei UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 136);
            textBox1.Location = new Point(518, 118);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(258, 38);
            textBox1.TabIndex = 3;
            textBox1.KeyDown += textBox1_KeyDown;
            // 
            // buttonSearch
            // 
            buttonSearch.Font = new Font("Microsoft JhengHei UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 136);
            buttonSearch.Location = new Point(794, 117);
            buttonSearch.Name = "buttonSearch";
            buttonSearch.Size = new Size(94, 39);
            buttonSearch.TabIndex = 4;
            buttonSearch.Text = "查詢";
            buttonSearch.UseVisualStyleBackColor = true;
            buttonSearch.Click += buttonSearch_Click;
            // 
            // buttonProvide
            // 
            buttonProvide.Font = new Font("Microsoft JhengHei UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 136);
            buttonProvide.Location = new Point(95, 117);
            buttonProvide.Name = "buttonProvide";
            buttonProvide.Size = new Size(370, 39);
            buttonProvide.TabIndex = 5;
            buttonProvide.Text = "資   料   提   供";
            buttonProvide.UseVisualStyleBackColor = true;
            buttonProvide.Click += buttonProvide_Click;
            // 
            // buttonSignout
            // 
            buttonSignout.Font = new Font("Microsoft JhengHei UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 136);
            buttonSignout.Location = new Point(794, 62);
            buttonSignout.Name = "buttonSignout";
            buttonSignout.Size = new Size(94, 39);
            buttonSignout.TabIndex = 6;
            buttonSignout.Text = "登出";
            buttonSignout.UseVisualStyleBackColor = true;
            buttonSignout.Click += btnsignout_Click;
            // 
            // AccountForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 192);
            ClientSize = new Size(984, 561);
            Controls.Add(buttonSignout);
            Controls.Add(buttonProvide);
            Controls.Add(buttonSearch);
            Controls.Add(textBox1);
            Controls.Add(listBox1);
            Controls.Add(panel1);
            Controls.Add(labelAccount);
            Name = "AccountForm";
            Text = "登入";
            Load += AccountForm_Load;
            panel1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label labelAccount;
        private Panel panel1;
        private ListBox listBox1;
        private Button btnApple;
        private Button btnPorkBlood;
        private Button btnKelp;
        private Button btnOrange;
        private Button btnMilk;
        private Button btnBanana;
        private Button btnCarrot;
        private Button btnPotato;
        private Button btnCucumber;
        private Button btnTomato;
        private Button btnGreenOnion;
        private Button btnHoney;
        private Button btnGarlic;
        private Button btnSpinach;
        private Button btnSoybean;
        private TextBox textBox1;
        private Button buttonSearch;
        private Button buttonProvide;
        private Button buttonSignout;
    }
}