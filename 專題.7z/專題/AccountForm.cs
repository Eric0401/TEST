﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 專題
{
    public partial class AccountForm : Form
    {
        public string AccountName => textBox1.Text.Trim();
        public AccountForm()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(textBox1.Text))
            {
                MessageBox.Show("請輸入帳號名稱");
                return;
            }

            this.DialogResult = DialogResult.OK;
            this.Close();
        }
    }
}
