﻿#nullable disable
using System;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;

namespace 專題
{
    public partial class AccountDetailForm : Form
    {
        private AccountData account;

        private static Dictionary<string, List<FoodConflictDetail>> foodConflicts = null;
        private List<FoodPairQuery> recentQueries = new();
        public class FoodConflictDetail
        {
            public string Conflict { get; set; }
            public string Reason { get; set; }
            public string Solution { get; set; }
        }
        public class FoodPairQuery
        {
            public string Food1 { get; set; }
            public string Food2 { get; set; }
            public string Result { get; set; }
            public DateTime Time { get; set; }
        }
        private void LoadFoodConflicts()
        {
            // ✅ 已經載入就直接跳出
            if (foodConflicts != null) return;

            string filePath = "foodConflicts.json";
            if (File.Exists(filePath))
            {
                try
                {
                    string json = File.ReadAllText(filePath);
                    foodConflicts = JsonSerializer.Deserialize<Dictionary<string, List<FoodConflictDetail>>>(json)
                                    ?? new Dictionary<string, List<FoodConflictDetail>>();
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"載入 foodConflicts.json 發生錯誤：{ex.Message}");
                    foodConflicts = new Dictionary<string, List<FoodConflictDetail>>();
                }
            }
            else
            {
                // ✅ 改成只顯示一次
                if (!System.Diagnostics.Debugger.IsAttached) // 開發模式可略過
                    MessageBox.Show("找不到 foodConflicts.json，將使用空白清單");

                foodConflicts = new Dictionary<string, List<FoodConflictDetail>>();
            }
        }

        public AccountDetailForm(AccountData selectedAccount)
        {
            InitializeComponent();
            account = selectedAccount;
            this.Load += AccountDetailForm_Load;
            btnViewRecords.Click += BtnViewRecords_Click;
        }

        private void AccountDetailForm_Load(object sender, EventArgs e)
        {
            label1.Text = $"帳號：{account.Name}";
            LoadFoodConflicts();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void BtnViewRecords_Click(object sender, EventArgs e)
        {
            var recordForm = new RecordListForm(account.Records);
            recordForm.ShowDialog();
        }

        private void btnSave_Click_1(object sender, EventArgs e)
        {
            string dateText = txtDate.Text.Trim();
            string food = txtFood.Text.Trim();

            if (!DateTime.TryParseExact(dateText, "yyyyMMdd", null, System.Globalization.DateTimeStyles.None, out DateTime date))
            {
                MessageBox.Show("請輸入正確的日期格式（例如：20250605）");
                return;
            }

            if (string.IsNullOrEmpty(food))
            {
                MessageBox.Show("請輸入食物內容");
                return;
            }

            // 加上現在時間（小時分鐘）
            DateTime fullDateTime = date.Add(DateTime.Now.TimeOfDay);

            // 新增這筆紀錄
            var newRecord = new DailyRecord
            {
                DateTime = fullDateTime,
                Food = food
            };
            account.Records.Add(newRecord);

            // 刪除超過兩週前的紀錄
            DateTime cutoff = DateTime.Now.AddDays(-14);
            account.Records.RemoveAll(r => r.DateTime < cutoff);

            // 儲存回主畫面
            ((Form1)Application.OpenForms["Form1"])?.SaveExternally();

            MessageBox.Show("儲存成功！");
            txtDate.Text = "";
            txtFood.Text = "";
        }

        private void btnCheckPair_Click(object sender, EventArgs e)
        {
            string food1 = txtFood1.Text.Trim();
            string food2 = txtFood2.Text.Trim();

            if (string.IsNullOrEmpty(food1) || string.IsNullOrEmpty(food2))
            {
                MessageBox.Show("請輸入兩種食物", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string resultMessage = null;

            foreach (var pair in new[] { (food1, food2), (food2, food1) })
            {
                if (foodConflicts.ContainsKey(pair.Item1))
                {
                    foreach (var conflict in foodConflicts[pair.Item1])
                    {
                        if (string.Equals(conflict.Conflict.Trim(), pair.Item2, StringComparison.OrdinalIgnoreCase))
                        {
                            resultMessage = $"❌ {food1} 和 {food2} 不建議同時食用！\n原因：{conflict.Reason}\n建議：{conflict.Solution}";
                            MessageBox.Show(resultMessage, "提醒", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                            goto SaveAndExit;
                        }
                    }
                }
            }

            resultMessage = $"✔ {food1} 和 {food2} 可以一起吃。";
            MessageBox.Show(resultMessage, "OK", MessageBoxButtons.OK, MessageBoxIcon.Information);

        SaveAndExit:
            // 儲存查詢記錄
            recentQueries.Insert(0, new FoodPairQuery
            {
                Food1 = food1,
                Food2 = food2,
                Result = resultMessage,
                Time = DateTime.Now
            });

            // 限制最多保留 5 筆
            if (recentQueries.Count > 5)
                recentQueries = recentQueries.Take(5).ToList();
        }

        private void btnRecent_Click(object sender, EventArgs e)
        {
            var form = new RecentRecordsForm(recentQueries);
            form.ShowDialog();
        }

    }
}
