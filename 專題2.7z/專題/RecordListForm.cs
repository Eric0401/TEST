﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace 專題
{
    public partial class RecordListForm : Form
    {
        public RecordListForm(List<DailyRecord> records)
        {
            InitializeComponent();
            this.Load += (s, e) =>
            {
                foreach (var record in records)
                {
                    var listItem = $"{record.DateTime:yyyy/MM/dd HH:mm} ({record.DateTime.DayOfWeek}) - {record.Food}";
                    listBox1.Items.Add(listItem);
                }
            };
        }
    }
}
