#nullable disable
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text.Json;
using System.Windows.Forms;
using System.Text.Encodings.Web;

namespace 專題
{
    public partial class Form1 : Form
    {
        bool isDeleteMode = false;
        Button deleteModeBtn;
        TextBox nameInput;
        Button createButton;
        List<AccountData> accountList = new List<AccountData>();
        string saveFile = "accounts.json";

        public Form1()
        {
            InitializeComponent();
            if (LicenseManager.UsageMode != LicenseUsageMode.Designtime)
            {
                LoadAccounts();
                RenderButtons();
            }
        }

        public void SaveExternally()
        {
            SaveAccounts();
        }

        private void SaveAccounts()
        {
            var options = new JsonSerializerOptions
            {
                WriteIndented = true,
                Encoder = JavaScriptEncoder.UnsafeRelaxedJsonEscaping // 讓中文正常顯示
            };
            string json = JsonSerializer.Serialize(accountList, options);
            File.WriteAllText(saveFile, json);
        }

        private void LoadAccounts()
        {
            if (File.Exists(saveFile))
            {
                string json = File.ReadAllText(saveFile);
                accountList = JsonSerializer.Deserialize<List<AccountData>>(json);
            }
        }

        private void RenderButtons()
        {
            this.Controls.Clear();

            int x = 10, y = 10;
            int btnWidth = 80, btnHeight = 80;
            int spacing = 10;
            int formWidth = this.ClientSize.Width;

            foreach (var account in accountList)
            {
                var currentAccount = account;
                Button accBtn = new Button();
                accBtn.Text = currentAccount.Name;
                accBtn.Size = new Size(btnWidth, btnHeight);
                accBtn.Location = new Point(x, y);

                accBtn.Click += (s, e) =>
                {
                    if (isDeleteMode)
                    {
                        var result = MessageBox.Show($"你確定要刪除帳號 {currentAccount.Name}？", "確認刪除", MessageBoxButtons.YesNo);
                        if (result == DialogResult.Yes)
                        {
                            accountList.Remove(currentAccount);
                            SaveAccounts();
                            RenderButtons();
                        }
                    }
                    else
                    {
                        this.Hide();
                        var detailForm = new AccountDetailForm(currentAccount);
                        if (detailForm.ShowDialog() == DialogResult.OK)
                        {
                            SaveAccounts(); // 使用者按了儲存後，回寫 JSON
                        }
                        this.Show();
                    }
                };

                this.Controls.Add(accBtn);

                x += btnWidth + spacing;
                if (x + btnWidth > formWidth)
                {
                    x = 10;
                    y += btnHeight + spacing;
                }
            }

            // 新增帳號 TextBox
            nameInput = new TextBox();
            nameInput.Name = "nameInput";
            nameInput.Size = new Size(150, 30);
            nameInput.Location = new Point(10, this.ClientSize.Height - 90);
            nameInput.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            this.Controls.Add(nameInput);

            // 新增帳號按鈕
            createButton = new Button();
            createButton.Text = "新增帳號";
            createButton.Size = new Size(100, 30);
            createButton.Location = new Point(170, this.ClientSize.Height - 90);
            createButton.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            createButton.Click += CreateButton_Click;
            this.Controls.Add(createButton);

            // 左下角「刪除模式」按鈕
            deleteModeBtn = new Button();
            deleteModeBtn.Text = isDeleteMode ? "返回" : "刪除";
            deleteModeBtn.Size = new Size(100, 30);
            deleteModeBtn.Location = new Point(10, this.ClientSize.Height - 50);
            deleteModeBtn.Anchor = AnchorStyles.Left | AnchorStyles.Bottom;
            deleteModeBtn.Click += DeleteModeBtn_Click;
            this.Controls.Add(deleteModeBtn);
        }

        private void CreateButton_Click(object sender, EventArgs e)
        {
            string inputName = nameInput.Text.Trim();
            if (string.IsNullOrWhiteSpace(inputName))
            {
                MessageBox.Show("請輸入帳號名稱");
                return;
            }

            if (accountList.Count >= 16)
            {
                MessageBox.Show("帳號已達上限（16個），無法再新增！");
                return;
            }

            if (accountList.Any(a => a.Name == inputName))
            {
                MessageBox.Show("此帳號名稱已存在！");
                return;
            }

            var newAccount = new AccountData
            {
                Name = inputName,
                CreatedDate = DateTime.Now
            };

            accountList.Add(newAccount);
            SaveAccounts();
            RenderButtons();
        }

        private void DeleteModeBtn_Click(object sender, EventArgs e)
        {
            isDeleteMode = !isDeleteMode;
            deleteModeBtn.Text = isDeleteMode ? "返回" : "刪除";
            MessageBox.Show(isDeleteMode ? "點擊帳號即可刪除" : "已退出");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // 已經整合到 CreateButton_Click，不再使用這個方法
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // 可留空
        }
    }

    public class AccountData
    {
        public string Name { get; set; }
        public DateTime CreatedDate { get; set; }
        public List<DailyRecord> Records { get; set; } = new List<DailyRecord>();
    }

    public class DailyRecord
    {
        public DateTime DateTime { get; set; }
        public string Food { get; set; }
        public DayOfWeek DayOfWeek => DateTime.DayOfWeek;
    }
}
