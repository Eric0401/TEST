﻿namespace 專題
{
    partial class AccountDetailForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            btnBack = new Button();
            txtDate = new TextBox();
            label2 = new Label();
            label3 = new Label();
            btnSave = new Button();
            txtFood = new TextBox();
            btnViewRecords = new Button();
            label4 = new Label();
            txtFood1 = new TextBox();
            btnCheckPair = new Button();
            label5 = new Label();
            txtFood2 = new TextBox();
            label6 = new Label();
            btnRecent = new Button();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Microsoft JhengHei UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label1.Location = new Point(54, 24);
            label1.Name = "label1";
            label1.Size = new Size(96, 35);
            label1.TabIndex = 0;
            label1.Text = "帳號：";
            // 
            // btnBack
            // 
            btnBack.Location = new Point(700, 405);
            btnBack.Name = "btnBack";
            btnBack.Size = new Size(75, 23);
            btnBack.TabIndex = 1;
            btnBack.Text = "登出";
            btnBack.UseVisualStyleBackColor = true;
            btnBack.Click += btnBack_Click;
            // 
            // txtDate
            // 
            txtDate.Font = new Font("Microsoft JhengHei UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtDate.Location = new Point(284, 234);
            txtDate.Multiline = true;
            txtDate.Name = "txtDate";
            txtDate.Size = new Size(213, 50);
            txtDate.TabIndex = 2;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Microsoft JhengHei UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label2.Location = new Point(54, 233);
            label2.Name = "label2";
            label2.Size = new Size(224, 82);
            label2.TabIndex = 4;
            label2.Text = "日期：\r\n(YYYYMMDD)";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft JhengHei UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label3.Location = new Point(54, 315);
            label3.Name = "label3";
            label3.Size = new Size(114, 41);
            label3.TabIndex = 5;
            label3.Text = "食物：";
            // 
            // btnSave
            // 
            btnSave.Font = new Font("Microsoft JhengHei UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnSave.Location = new Point(507, 230);
            btnSave.Name = "btnSave";
            btnSave.Size = new Size(123, 123);
            btnSave.TabIndex = 6;
            btnSave.Text = "儲存";
            btnSave.UseVisualStyleBackColor = true;
            btnSave.Click += btnSave_Click_1;
            // 
            // txtFood
            // 
            txtFood.Font = new Font("Microsoft JhengHei UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtFood.Location = new Point(284, 303);
            txtFood.Multiline = true;
            txtFood.Name = "txtFood";
            txtFood.Size = new Size(213, 50);
            txtFood.TabIndex = 7;
            // 
            // btnViewRecords
            // 
            btnViewRecords.Font = new Font("Microsoft JhengHei UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnViewRecords.Location = new Point(636, 230);
            btnViewRecords.Name = "btnViewRecords";
            btnViewRecords.Size = new Size(139, 123);
            btnViewRecords.TabIndex = 8;
            btnViewRecords.Text = "歷史紀錄";
            btnViewRecords.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Microsoft JhengHei UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label4.Location = new Point(54, 87);
            label4.Name = "label4";
            label4.Size = new Size(138, 26);
            label4.TabIndex = 9;
            label4.Text = "第一種食物：";
            // 
            // txtFood1
            // 
            txtFood1.Font = new Font("Microsoft JhengHei UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtFood1.Location = new Point(216, 81);
            txtFood1.Name = "txtFood1";
            txtFood1.Size = new Size(133, 38);
            txtFood1.TabIndex = 11;
            // 
            // btnCheckPair
            // 
            btnCheckPair.Font = new Font("Microsoft JhengHei UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnCheckPair.Location = new Point(380, 81);
            btnCheckPair.Name = "btnCheckPair";
            btnCheckPair.Size = new Size(97, 102);
            btnCheckPair.TabIndex = 13;
            btnCheckPair.Text = "配對";
            btnCheckPair.UseVisualStyleBackColor = true;
            btnCheckPair.Click += btnCheckPair_Click;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Microsoft JhengHei UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label5.Location = new Point(54, 151);
            label5.Name = "label5";
            label5.Size = new Size(138, 26);
            label5.TabIndex = 14;
            label5.Text = "第二種食物：";
            // 
            // txtFood2
            // 
            txtFood2.Font = new Font("Microsoft JhengHei UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtFood2.Location = new Point(216, 145);
            txtFood2.Name = "txtFood2";
            txtFood2.Size = new Size(133, 38);
            txtFood2.TabIndex = 15;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Microsoft JhengHei UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label6.Location = new Point(32, 186);
            label6.Name = "label6";
            label6.Size = new Size(743, 30);
            label6.TabIndex = 16;
            label6.Text = "-------------------------------------------------------------------------";
            // 
            // btnRecent
            // 
            btnRecent.Font = new Font("Microsoft JhengHei UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnRecent.Location = new Point(483, 81);
            btnRecent.Name = "btnRecent";
            btnRecent.Size = new Size(114, 102);
            btnRecent.TabIndex = 17;
            btnRecent.Text = "歷史紀錄";
            btnRecent.UseVisualStyleBackColor = true;
            btnRecent.Click += btnRecent_Click;
            // 
            // AccountDetailForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(btnRecent);
            Controls.Add(label6);
            Controls.Add(txtFood2);
            Controls.Add(label5);
            Controls.Add(btnCheckPair);
            Controls.Add(txtFood1);
            Controls.Add(label4);
            Controls.Add(btnViewRecords);
            Controls.Add(txtFood);
            Controls.Add(btnSave);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(txtDate);
            Controls.Add(btnBack);
            Controls.Add(label1);
            Name = "AccountDetailForm";
            Text = "日誌";
            Load += AccountDetailForm_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button btnBack;
        private TextBox txtDate;
        private Label label2;
        private Label label3;
        private Button btnSave;
        private TextBox txtFood;
        private Button btnViewRecords;
        private Label label4;
        private TextBox txtFood1;
        private Button btnCheckPair;
        private Label label5;
        private TextBox txtFood2;
        private Label label6;
        private Button btnRecent;
    }
}