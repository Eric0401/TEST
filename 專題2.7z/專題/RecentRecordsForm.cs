﻿#nullable disable
using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;

namespace 專題
{
    public partial class RecentRecordsForm : Form
    {
        private List<AccountDetailForm.FoodPairQuery> recentQueries;

        public RecentRecordsForm(List<AccountDetailForm.FoodPairQuery> queries)
        {
            InitializeComponent();
            recentQueries = queries;
            this.Load += RecentRecordsForm_Load;
        }

        private void RecentRecordsForm_Load(object sender, EventArgs e)
        {
            listBox1.Items.Clear();

            if (recentQueries == null || recentQueries.Count == 0)
            {
                listBox1.Items.Add("尚無最近查詢紀錄");
                return;
            }

            foreach (var q in recentQueries)
            {
                listBox1.Items.Add($"【{q.Time:HH:mm:ss}】{q.Food1} 和 {q.Food2}");
                listBox1.Items.Add($"→ {q.Result}");
                listBox1.Items.Add(""); // 空白行作為分隔
            }
        }
    }
}
