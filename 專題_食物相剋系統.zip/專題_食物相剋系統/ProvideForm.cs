﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Windows.Forms;

namespace 專題_食物相剋系統
{
    public partial class ProvideForm : Form
    {
        private FormResizer resizer = new FormResizer();

        public ProvideForm()
        {
            InitializeComponent();
            this.Load += ProvideForm_Load;
            this.Resize += ProvideForm_Resize;
        }

        // 載入表單時初始化畫面與食物資料列表
        private void ProvideForm_Load(object sender, EventArgs e)
        {
            resizer.CaptureOriginal(this);
            string path = Path.Combine(Application.StartupPath, "food.json");

            if (File.Exists(path))
            {
                string json = File.ReadAllText(path, Encoding.UTF8);
                var foodData = JsonSerializer.Deserialize<Dictionary<string, Form1.FoodData>>(json);

                comboBoxDelete.Items.Clear();
                comboBoxDelete.Items.AddRange(foodData.Keys.ToArray());
            }
        }

        private void ProvideForm_Resize(object sender, EventArgs e)
        {
            resizer.ResizeAll(this);
        }

        // 儲存新增或修改的食物資料
        private void buttonSave_Click(object sender, EventArgs e)
        {
            string foodName = txtFood.Text.Trim();
            if (string.IsNullOrEmpty(foodName))
            {
                MessageBox.Show("請輸入食物名稱");
                return;
            }

            // 將輸入字串拆分為清單並整理
            var newData = new Form1.FoodData
            {
                優點 = txtAdvantage.Text.Split(',', StringSplitOptions.RemoveEmptyEntries).Select(s => s.Trim()).ToList(),
                相剋 = txtConflict.Text.Split(',', StringSplitOptions.RemoveEmptyEntries).Select(s => s.Trim()).ToList(),
                後果 = txtConsequence.Text.Trim(),
                解決辦法 = txtSolution.Text.Trim()
            };

            string path = Path.Combine(Application.StartupPath, "food.json");

            // 載入原本資料或新建空字典
            Dictionary<string, Form1.FoodData> foodDict = File.Exists(path)
                ? JsonSerializer.Deserialize<Dictionary<string, Form1.FoodData>>(File.ReadAllText(path, Encoding.UTF8))
                : new Dictionary<string, Form1.FoodData>();

            // 新增或更新字典中的資料
            foodDict[foodName] = newData;

            // 寫入 JSON 檔
            string jsonOutput = JsonSerializer.Serialize(foodDict, new JsonSerializerOptions
            {
                WriteIndented = true,
                Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
            });
            File.WriteAllText(path, jsonOutput, Encoding.UTF8);

            // 更新全域字典以即時反映資料變更
            Form1.foodInfo = foodDict;

            // 清空輸入欄位
            txtFood.Text = txtAdvantage.Text = txtConflict.Text = txtConsequence.Text = txtSolution.Text = "";

            // 將新增食物加入刪除下拉選單（避免重複）
            if (!comboBoxDelete.Items.Contains(foodName))
                comboBoxDelete.Items.Add(foodName);

            // 若 AccountForm 已開啟，動態新增對應按鈕
            if (Application.OpenForms["AccountForm"] is AccountForm accountForm)
            {
                accountForm.Invoke(() => accountForm.AddFoodButtonAtFront(foodName));
            }
        }

        // 返回 AccountForm 主視窗
        private void buttonBack_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["AccountForm"] is Form mainForm)
                mainForm.Show();
            this.Close();
        }

        // 刪除選取的食物資料
        private void btnDeleteFood_Click(object sender, EventArgs e)
        {
            string foodToDelete = comboBoxDelete.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(foodToDelete))
            {
                MessageBox.Show("請先選擇要刪除的食物", "提醒", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string path = Path.Combine(Application.StartupPath, "food.json");
            string json = File.ReadAllText(path, Encoding.UTF8);
            var foodData = JsonSerializer.Deserialize<Dictionary<string, Form1.FoodData>>(json);

            // 從字典刪除選中食物
            if (foodData.Remove(foodToDelete))
            {
                // 寫回 JSON 檔案
                string updated = JsonSerializer.Serialize(foodData, new JsonSerializerOptions
                {
                    WriteIndented = true,
                    Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
                });
                File.WriteAllText(path, updated, Encoding.UTF8);
                Form1.foodInfo = foodData;

                // 從下拉選單移除該食物
                comboBoxDelete.Items.Remove(foodToDelete);
                comboBoxDelete.Text = "";

                // 若 AccountForm 已開啟，移除對應動態按鈕
                if (Application.OpenForms["AccountForm"] is AccountForm accountForm)
                {
                    accountForm.RemoveFoodButton(foodToDelete);
                }
            }
        }
    }
}
