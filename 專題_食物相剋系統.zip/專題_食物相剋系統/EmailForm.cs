﻿using System;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace 專題_食物相剋系統
{
    public partial class EmailForm : Form
    {
        private string foodName;  // 要寄送的食物名稱

        public EmailForm(string foodName)
        {
            InitializeComponent();
            this.foodName = foodName;
            this.Text = $"寄送食物資訊：{foodName}"; // 視窗標題
        }

        // 按下寄信按鈕事件
        private void btnSend_Click(object sender, EventArgs e)
        {
            string toEmail = txtEmail.Text.Trim();

            // 檢查Email格式
            if (!IsValidEmail(toEmail))
            {
                MessageBox.Show("請輸入有效的 Email 地址", "格式錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                // 建立信件主旨與內容
                string subject = $"食物資訊：{foodName}";
                string body = ComposeFoodEmailBody(foodName);

                // 呼叫寄信函式
                SendEmail(toEmail, subject, body);

                MessageBox.Show("郵件已成功寄出", "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            catch (SmtpException smtpEx)
            {
                MessageBox.Show($"SMTP 發生錯誤：{smtpEx.StatusCode} - {smtpEx.Message}", "寄信錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"寄信失敗：{ex.Message}", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // 清空 Email 輸入框並聚焦
        private void btnClear_Click(object sender, EventArgs e)
        {
            txtEmail.Clear();
            txtEmail.Focus();
        }

        // 按下返回按鈕關閉視窗
        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // 利用正規表示式簡單驗證 Email 格式
        private bool IsValidEmail(string email)
        {
            return Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$");
        }

        // 根據 foodName 組合郵件內容
        private string ComposeFoodEmailBody(string foodName)
        {
            if (!Form1.foodInfo.ContainsKey(foodName))
                return $"查無此食物資料：{foodName}";

            var food = Form1.foodInfo[foodName];
            var sb = new StringBuilder();
            sb.AppendLine($"【食物名稱】：{foodName}\n");

            sb.AppendLine("📌 優點：");
            if (food.優點 != null)
                foreach (var pro in food.優點)
                    sb.AppendLine($"- {pro}");
            else
                sb.AppendLine("- 無資料");

            sb.AppendLine("\n⚠️ 相剋：");
            if (food.相剋 != null)
                foreach (var con in food.相剋)
                    sb.AppendLine($"- {con}");
            else
                sb.AppendLine("- 無資料");

            sb.AppendLine($"\n後果：{food.後果}");
            sb.AppendLine($"解決辦法：{food.解決辦法}");

            return sb.ToString();
        }

        // 寄送 Email 的方法，使用 Gmail SMTP
        private void SendEmail(string toEmail, string subject, string body)
        {
            // 請自行替換成有效的 Gmail 帳號與應用程式密碼
            string fromEmail = "FoodIncompatibilityManager@gmail.com";
            string appPassword = "kxckpxmlkdkgavye";

            using var smtpClient = new SmtpClient("smtp.gmail.com", 587)
            {
                Credentials = new NetworkCredential(fromEmail, appPassword),
                EnableSsl = true
            };

            MailMessage mail = new MailMessage()
            {
                From = new MailAddress(fromEmail, "食物相剋系統"),
                Subject = subject,
                IsBodyHtml = true,  // HTML格式郵件
                Body = $"<html><body><pre>{body}</pre></body></html>"
            };
            mail.To.Add(toEmail);
            // 提供純文字版本以利不支援 HTML 的郵件用戶端
            mail.AlternateViews.Add(AlternateView.CreateAlternateViewFromString(body, null, "text/plain"));

            smtpClient.Send(mail);
        }
    }
}
