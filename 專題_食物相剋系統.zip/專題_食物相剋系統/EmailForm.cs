﻿using System;
using System.Net;
using System.Net.Mail;
using System.Text;
using System.Text.RegularExpressions;
using System.Windows.Forms;

namespace 專題_食物相剋系統
{
    public partial class EmailForm : Form
    {
        private string foodName;

        public EmailForm(string foodName)
        {
            InitializeComponent();
            this.foodName = foodName;
            this.Text = $"寄送食物資訊：{foodName}";
        }

        private void btnSend_Click(object sender, EventArgs e)
        {
            string toEmail = txtEmail.Text.Trim();

            if (!IsValidEmail(toEmail))
            {
                MessageBox.Show("請輸入有效的 Email 地址", "格式錯誤", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                string subject = $"食物資訊：{foodName}";
                string body = ComposeFoodEmailBody(foodName);

                SendEmail(toEmail, subject, body);

                MessageBox.Show("郵件已成功寄出", "成功", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"寄信失敗：{ex.Message}", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtEmail.Clear();
            txtEmail.Focus();
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private bool IsValidEmail(string email)
        {
            return Regex.IsMatch(email, @"^[^@\s]+@[^@\s]+\.[^@\s]+$");
        }

        private string ComposeFoodEmailBody(string foodName)
        {
            if (!Form1.foodInfo.ContainsKey(foodName))
                return $"查無此食物資料：{foodName}";

            var food = Form1.foodInfo[foodName];
            StringBuilder sb = new StringBuilder();
            sb.AppendLine($"【食物名稱】：{foodName}\n");
            sb.AppendLine("📌 優點：");
            if (food.優點 != null)
            {
                foreach (var pro in food.優點)
                    sb.AppendLine($"- {pro}");
            }
            else
            {
                sb.AppendLine("- 無資料");
            }
            sb.AppendLine("\n⚠️ 相剋：");
            if (food.相剋 != null)
            {
                foreach (var con in food.相剋)
                    sb.AppendLine($"- {con}");
            }
            else
            {
                sb.AppendLine("- 無資料");
            }
            sb.AppendLine($"\n後果：{food.後果}");
            sb.AppendLine($"解決辦法：{food.解決辦法}");

            return sb.ToString();
        }

        private void SendEmail(string toEmail, string subject, string body)
        {
            // Gmail SMTP 設定，請自行替換成你的帳號與應用程式密碼
            string fromEmail = "FoodIncompatibilityManager@gmail.com"; //帳號FoodIncompatibilityManager@gmail.com，密碼Foodfood
            string appPassword = "kxckpxmlkdkgavye";

            using (var smtpClient = new SmtpClient("smtp.gmail.com", 587))
            {
                smtpClient.Credentials = new NetworkCredential(fromEmail, appPassword);
                smtpClient.EnableSsl = true;

                MailMessage mail = new MailMessage(fromEmail, toEmail, subject, body);
                smtpClient.Send(mail);
            }
        }
    }
}
