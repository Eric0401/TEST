﻿namespace 專題_食物相剋系統
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            btnConfirm = new Button();
            textBox1 = new TextBox();
            comboBox1 = new ComboBox();
            labelMarquee = new Label();
            timerScroll = new System.Windows.Forms.Timer(components);
            timer1 = new System.Windows.Forms.Timer(components);
            timerColor = new System.Windows.Forms.Timer(components);
            pictureBox1 = new PictureBox();
            btnLogin = new Button();
            btnDelete = new Button();
            label2 = new Label();
            label1 = new Label();
            label3 = new Label();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // btnConfirm
            // 
            btnConfirm.BackColor = Color.White;
            btnConfirm.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnConfirm.Location = new Point(810, 293);
            btnConfirm.Name = "btnConfirm";
            btnConfirm.Size = new Size(77, 32);
            btnConfirm.TabIndex = 1;
            btnConfirm.Text = "確認";
            btnConfirm.UseVisualStyleBackColor = false;
            btnConfirm.Click += btnConfirm_Click;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("標楷體", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            textBox1.Location = new Point(624, 295);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(166, 33);
            textBox1.TabIndex = 2;
            // 
            // comboBox1
            // 
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.Font = new Font("標楷體", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(624, 390);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(166, 29);
            comboBox1.TabIndex = 4;
            // 
            // labelMarquee
            // 
            labelMarquee.AutoSize = true;
            labelMarquee.BackColor = Color.White;
            labelMarquee.Font = new Font("Microsoft JhengHei UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            labelMarquee.Location = new Point(917, 51);
            labelMarquee.Name = "labelMarquee";
            labelMarquee.Size = new Size(67, 24);
            labelMarquee.TabIndex = 8;
            labelMarquee.Text = "跑馬燈";
            // 
            // timerScroll
            // 
            timerScroll.Enabled = true;
            timerScroll.Interval = 50;
            timerScroll.Tick += timerScroll_Tick;
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Interval = 50;
            // 
            // timerColor
            // 
            timerColor.Enabled = true;
            timerColor.Interval = 200;
            timerColor.Tick += timerColor_Tick;
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox1.Dock = DockStyle.Fill;
            pictureBox1.Image = Properties.Resources.background_1;
            pictureBox1.Location = new Point(0, 0);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(984, 561);
            pictureBox1.TabIndex = 9;
            pictureBox1.TabStop = false;
            // 
            // btnLogin
            // 
            btnLogin.BackColor = Color.White;
            btnLogin.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnLogin.Location = new Point(810, 390);
            btnLogin.Name = "btnLogin";
            btnLogin.Size = new Size(77, 32);
            btnLogin.TabIndex = 9;
            btnLogin.Text = "登入";
            btnLogin.UseVisualStyleBackColor = false;
            btnLogin.Click += btnLogin_Click;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.White;
            btnDelete.Font = new Font("標楷體", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnDelete.Location = new Point(810, 458);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(77, 32);
            btnDelete.TabIndex = 10;
            btnDelete.Text = "刪除";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.White;
            label2.Font = new Font("標楷體", 18F, FontStyle.Bold, GraphicsUnit.Point, 136);
            label2.ForeColor = Color.White;
            label2.Location = new Point(465, 390);
            label2.Name = "label2";
            label2.Size = new Size(135, 24);
            label2.TabIndex = 5;
            label2.Text = "切換帳號：";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.White;
            label1.Font = new Font("標楷體", 18F, FontStyle.Bold, GraphicsUnit.Point, 136);
            label1.ForeColor = Color.White;
            label1.Location = new Point(465, 296);
            label1.Name = "label1";
            label1.Size = new Size(135, 24);
            label1.TabIndex = 0;
            label1.Text = "建立帳號：";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BackColor = Color.White;
            label3.Font = new Font("標楷體", 18F, FontStyle.Bold, GraphicsUnit.Point, 136);
            label3.ForeColor = Color.White;
            label3.Location = new Point(465, 201);
            label3.Name = "label3";
            label3.Size = new Size(300, 48);
            label3.TabIndex = 11;
            label3.Text = "輸入Guest時切為訪客模式\r\n輸入Choose切換帳號";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.White;
            label4.Font = new Font("標楷體", 26.25F, FontStyle.Bold, GraphicsUnit.Point, 136);
            label4.ForeColor = Color.White;
            label4.Location = new Point(589, 122);
            label4.Name = "label4";
            label4.Size = new Size(237, 35);
            label4.TabIndex = 12;
            label4.Text = "食物相剋系統";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Cornsilk;
            ClientSize = new Size(984, 561);
            Controls.Add(labelMarquee);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(btnLogin);
            Controls.Add(label1);
            Controls.Add(btnDelete);
            Controls.Add(label2);
            Controls.Add(comboBox1);
            Controls.Add(textBox1);
            Controls.Add(btnConfirm);
            Controls.Add(pictureBox1);
            Name = "Form1";
            Text = "食物相剋系統";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button btnConfirm;
        private TextBox textBox1;
        private ComboBox comboBox1;
        private Label labelMarquee;
        private System.Windows.Forms.Timer timerScroll;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timerColor;
        private PictureBox pictureBox1;
        private Button btnLogin;
        private Button btnDelete;
        private Label label2;
        private Label label1;
        private Label label3;
        private Label label4;
    }
}
