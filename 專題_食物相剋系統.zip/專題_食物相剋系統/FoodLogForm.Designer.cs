﻿namespace 專題_食物相剋系統
{
    partial class FoodLogForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            tableLayoutPanel1 = new TableLayoutPanel();
            txtOther = new TextBox();
            radioOther = new RadioButton();
            radioMorning = new RadioButton();
            radioSupper = new RadioButton();
            radioLunch = new RadioButton();
            radioDinner = new RadioButton();
            groupBox2 = new GroupBox();
            tableLayoutPanel2 = new TableLayoutPanel();
            lblNote = new Label();
            lblFoodName1 = new Label();
            txtNote = new TextBox();
            txtFoodName = new TextBox();
            btnSaveRecord = new Button();
            listBox1 = new ListBox();
            label6 = new Label();
            labelAccount = new Label();
            buttonBack2 = new Button();
            tableLayoutPanel4 = new TableLayoutPanel();
            tableLayoutPanel3 = new TableLayoutPanel();
            comboBoxDaySelector = new ComboBox();
            btnDeleteRecord = new Button();
            tableLayoutPanel5 = new TableLayoutPanel();
            tableLayoutPanel6 = new TableLayoutPanel();
            btnExportWeeklyReport = new Button();
            btnStatistics = new Button();
            groupBox1.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            groupBox2.SuspendLayout();
            tableLayoutPanel2.SuspendLayout();
            tableLayoutPanel4.SuspendLayout();
            tableLayoutPanel3.SuspendLayout();
            tableLayoutPanel5.SuspendLayout();
            tableLayoutPanel6.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(tableLayoutPanel1);
            groupBox1.Dock = DockStyle.Fill;
            groupBox1.Font = new Font("標楷體", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            groupBox1.Location = new Point(0, 0);
            groupBox1.Margin = new Padding(0);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(203, 275);
            groupBox1.TabIndex = 0;
            groupBox1.TabStop = false;
            groupBox1.Text = "餐別選擇";
            groupBox1.Paint += groupBox1_Paint;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 105F));
            tableLayoutPanel1.Controls.Add(txtOther, 1, 4);
            tableLayoutPanel1.Controls.Add(radioOther, 0, 4);
            tableLayoutPanel1.Controls.Add(radioMorning, 0, 0);
            tableLayoutPanel1.Controls.Add(radioSupper, 0, 3);
            tableLayoutPanel1.Controls.Add(radioLunch, 0, 1);
            tableLayoutPanel1.Controls.Add(radioDinner, 0, 2);
            tableLayoutPanel1.Font = new Font("標楷體", 18F, FontStyle.Regular, GraphicsUnit.Point, 136);
            tableLayoutPanel1.Location = new Point(3, 28);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 5;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanel1.Size = new Size(197, 243);
            tableLayoutPanel1.TabIndex = 19;
            // 
            // txtOther
            // 
            txtOther.Anchor = AnchorStyles.None;
            txtOther.Enabled = false;
            txtOther.Location = new Point(95, 199);
            txtOther.Name = "txtOther";
            txtOther.Size = new Size(99, 36);
            txtOther.TabIndex = 19;
            // 
            // radioOther
            // 
            radioOther.Anchor = AnchorStyles.None;
            radioOther.AutoSize = true;
            radioOther.Location = new Point(8, 203);
            radioOther.Name = "radioOther";
            radioOther.Size = new Size(76, 28);
            radioOther.TabIndex = 4;
            radioOther.TabStop = true;
            radioOther.Text = "其他";
            radioOther.UseVisualStyleBackColor = true;
            radioOther.CheckedChanged += radioOther_CheckedChanged;
            // 
            // radioMorning
            // 
            radioMorning.Anchor = AnchorStyles.None;
            radioMorning.AutoSize = true;
            radioMorning.Location = new Point(8, 10);
            radioMorning.Name = "radioMorning";
            radioMorning.Size = new Size(76, 28);
            radioMorning.TabIndex = 0;
            radioMorning.TabStop = true;
            radioMorning.Text = "早餐";
            radioMorning.UseVisualStyleBackColor = true;
            // 
            // radioSupper
            // 
            radioSupper.Anchor = AnchorStyles.None;
            radioSupper.AutoSize = true;
            radioSupper.Location = new Point(8, 154);
            radioSupper.Name = "radioSupper";
            radioSupper.Size = new Size(76, 28);
            radioSupper.TabIndex = 3;
            radioSupper.TabStop = true;
            radioSupper.Text = "宵夜";
            radioSupper.UseVisualStyleBackColor = true;
            // 
            // radioLunch
            // 
            radioLunch.Anchor = AnchorStyles.None;
            radioLunch.AutoSize = true;
            radioLunch.Location = new Point(8, 58);
            radioLunch.Name = "radioLunch";
            radioLunch.Size = new Size(76, 28);
            radioLunch.TabIndex = 1;
            radioLunch.TabStop = true;
            radioLunch.Text = "午餐";
            radioLunch.UseVisualStyleBackColor = true;
            // 
            // radioDinner
            // 
            radioDinner.Anchor = AnchorStyles.None;
            radioDinner.AutoSize = true;
            radioDinner.Location = new Point(8, 106);
            radioDinner.Name = "radioDinner";
            radioDinner.Size = new Size(76, 28);
            radioDinner.TabIndex = 2;
            radioDinner.TabStop = true;
            radioDinner.Text = "晚餐";
            radioDinner.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(tableLayoutPanel2);
            groupBox2.Font = new Font("標楷體", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            groupBox2.Location = new Point(203, 0);
            groupBox2.Margin = new Padding(0);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(284, 274);
            groupBox2.TabIndex = 1;
            groupBox2.TabStop = false;
            groupBox2.Text = "食物紀錄";
            groupBox2.Paint += groupBox2_Paint;
            // 
            // tableLayoutPanel2
            // 
            tableLayoutPanel2.ColumnCount = 2;
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 45.55556F));
            tableLayoutPanel2.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 54.4444427F));
            tableLayoutPanel2.Controls.Add(lblNote, 0, 1);
            tableLayoutPanel2.Controls.Add(lblFoodName1, 0, 0);
            tableLayoutPanel2.Controls.Add(txtNote, 1, 1);
            tableLayoutPanel2.Controls.Add(txtFoodName, 1, 0);
            tableLayoutPanel2.Controls.Add(btnSaveRecord, 0, 2);
            tableLayoutPanel2.Dock = DockStyle.Fill;
            tableLayoutPanel2.Location = new Point(3, 29);
            tableLayoutPanel2.Name = "tableLayoutPanel2";
            tableLayoutPanel2.RowCount = 3;
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 25F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 60F));
            tableLayoutPanel2.RowStyles.Add(new RowStyle(SizeType.Percent, 15F));
            tableLayoutPanel2.Size = new Size(278, 242);
            tableLayoutPanel2.TabIndex = 4;
            // 
            // lblNote
            // 
            lblNote.Anchor = AnchorStyles.None;
            lblNote.AutoSize = true;
            lblNote.Location = new Point(25, 122);
            lblNote.Name = "lblNote";
            lblNote.Size = new Size(76, 21);
            lblNote.TabIndex = 4;
            lblNote.Text = "備註：";
            // 
            // lblFoodName1
            // 
            lblFoodName1.Anchor = AnchorStyles.None;
            lblFoodName1.AutoSize = true;
            lblFoodName1.Location = new Point(3, 19);
            lblFoodName1.Name = "lblFoodName1";
            lblFoodName1.Size = new Size(120, 21);
            lblFoodName1.TabIndex = 0;
            lblFoodName1.Text = "食物名稱：";
            // 
            // txtNote
            // 
            txtNote.Dock = DockStyle.Fill;
            txtNote.Location = new Point(129, 63);
            txtNote.Multiline = true;
            txtNote.Name = "txtNote";
            txtNote.ScrollBars = ScrollBars.Vertical;
            txtNote.Size = new Size(146, 139);
            txtNote.TabIndex = 2;
            // 
            // txtFoodName
            // 
            txtFoodName.Anchor = AnchorStyles.None;
            txtFoodName.Location = new Point(134, 13);
            txtFoodName.Name = "txtFoodName";
            txtFoodName.Size = new Size(135, 33);
            txtFoodName.TabIndex = 1;
            // 
            // btnSaveRecord
            // 
            tableLayoutPanel2.SetColumnSpan(btnSaveRecord, 2);
            btnSaveRecord.Dock = DockStyle.Fill;
            btnSaveRecord.Image = Properties.Resources.icons8_save_24;
            btnSaveRecord.Location = new Point(0, 205);
            btnSaveRecord.Margin = new Padding(0);
            btnSaveRecord.Name = "btnSaveRecord";
            btnSaveRecord.Size = new Size(278, 37);
            btnSaveRecord.TabIndex = 5;
            btnSaveRecord.UseVisualStyleBackColor = true;
            btnSaveRecord.Click += btnSaveRecord_Click;
            // 
            // listBox1
            // 
            listBox1.Dock = DockStyle.Fill;
            listBox1.Font = new Font("標楷體", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            listBox1.FormattingEnabled = true;
            listBox1.Location = new Point(0, 40);
            listBox1.Margin = new Padding(0);
            listBox1.Name = "listBox1";
            listBox1.Size = new Size(319, 188);
            listBox1.TabIndex = 2;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("標楷體", 26.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label6.Location = new Point(390, 52);
            label6.Name = "label6";
            label6.Size = new Size(237, 35);
            label6.TabIndex = 17;
            label6.Text = "紀錄查閱飲食";
            // 
            // labelAccount
            // 
            labelAccount.AutoSize = true;
            labelAccount.Font = new Font("標楷體", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            labelAccount.Location = new Point(89, 62);
            labelAccount.Name = "labelAccount";
            labelAccount.Size = new Size(110, 27);
            labelAccount.TabIndex = 18;
            labelAccount.Text = "帳號： ";
            // 
            // buttonBack2
            // 
            buttonBack2.Dock = DockStyle.Fill;
            buttonBack2.Image = Properties.Resources.icons8_return_48;
            buttonBack2.Location = new Point(3, 53);
            buttonBack2.Name = "buttonBack2";
            buttonBack2.Size = new Size(806, 44);
            buttonBack2.TabIndex = 19;
            buttonBack2.UseVisualStyleBackColor = true;
            buttonBack2.Click += buttonBack2_Click;
            // 
            // tableLayoutPanel4
            // 
            tableLayoutPanel4.BackColor = Color.Cornsilk;
            tableLayoutPanel4.ColumnCount = 3;
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25F));
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 35F));
            tableLayoutPanel4.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 40F));
            tableLayoutPanel4.Controls.Add(tableLayoutPanel3, 2, 0);
            tableLayoutPanel4.Controls.Add(groupBox1, 0, 0);
            tableLayoutPanel4.Controls.Add(groupBox2, 1, 0);
            tableLayoutPanel4.Location = new Point(89, 143);
            tableLayoutPanel4.Name = "tableLayoutPanel4";
            tableLayoutPanel4.RowCount = 1;
            tableLayoutPanel4.RowStyles.Add(new RowStyle());
            tableLayoutPanel4.Size = new Size(812, 274);
            tableLayoutPanel4.TabIndex = 21;
            // 
            // tableLayoutPanel3
            // 
            tableLayoutPanel3.ColumnCount = 1;
            tableLayoutPanel3.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel3.Controls.Add(comboBoxDaySelector, 0, 0);
            tableLayoutPanel3.Controls.Add(listBox1, 0, 1);
            tableLayoutPanel3.Controls.Add(btnDeleteRecord, 0, 2);
            tableLayoutPanel3.Location = new Point(490, 3);
            tableLayoutPanel3.Name = "tableLayoutPanel3";
            tableLayoutPanel3.RowCount = 3;
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 15F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 70F));
            tableLayoutPanel3.RowStyles.Add(new RowStyle(SizeType.Percent, 15F));
            tableLayoutPanel3.Size = new Size(319, 269);
            tableLayoutPanel3.TabIndex = 22;
            // 
            // comboBoxDaySelector
            // 
            comboBoxDaySelector.Dock = DockStyle.Fill;
            comboBoxDaySelector.Font = new Font("標楷體", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            comboBoxDaySelector.FormattingEnabled = true;
            comboBoxDaySelector.Location = new Point(0, 0);
            comboBoxDaySelector.Margin = new Padding(0);
            comboBoxDaySelector.MaxDropDownItems = 14;
            comboBoxDaySelector.Name = "comboBoxDaySelector";
            comboBoxDaySelector.Size = new Size(319, 29);
            comboBoxDaySelector.TabIndex = 3;
            comboBoxDaySelector.SelectedIndexChanged += comboBoxDaySelector_SelectedIndexChanged;
            // 
            // btnDeleteRecord
            // 
            btnDeleteRecord.Dock = DockStyle.Fill;
            btnDeleteRecord.Image = Properties.Resources.icons8_full_trash_24;
            btnDeleteRecord.Location = new Point(0, 228);
            btnDeleteRecord.Margin = new Padding(0);
            btnDeleteRecord.Name = "btnDeleteRecord";
            btnDeleteRecord.Size = new Size(319, 41);
            btnDeleteRecord.TabIndex = 4;
            btnDeleteRecord.UseVisualStyleBackColor = true;
            btnDeleteRecord.Click += btnDeleteRecord_Click;
            // 
            // tableLayoutPanel5
            // 
            tableLayoutPanel5.ColumnCount = 1;
            tableLayoutPanel5.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100F));
            tableLayoutPanel5.Controls.Add(tableLayoutPanel6, 0, 0);
            tableLayoutPanel5.Controls.Add(buttonBack2, 0, 1);
            tableLayoutPanel5.Location = new Point(89, 440);
            tableLayoutPanel5.Name = "tableLayoutPanel5";
            tableLayoutPanel5.RowCount = 2;
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel5.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel5.Size = new Size(812, 100);
            tableLayoutPanel5.TabIndex = 22;
            // 
            // tableLayoutPanel6
            // 
            tableLayoutPanel6.ColumnCount = 2;
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel6.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel6.Controls.Add(btnExportWeeklyReport, 1, 0);
            tableLayoutPanel6.Controls.Add(btnStatistics, 0, 0);
            tableLayoutPanel6.Dock = DockStyle.Fill;
            tableLayoutPanel6.Location = new Point(3, 3);
            tableLayoutPanel6.Name = "tableLayoutPanel6";
            tableLayoutPanel6.RowCount = 1;
            tableLayoutPanel6.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel6.Size = new Size(806, 44);
            tableLayoutPanel6.TabIndex = 23;
            // 
            // btnExportWeeklyReport
            // 
            btnExportWeeklyReport.Dock = DockStyle.Fill;
            btnExportWeeklyReport.Font = new Font("標楷體", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnExportWeeklyReport.Location = new Point(403, 0);
            btnExportWeeklyReport.Margin = new Padding(0);
            btnExportWeeklyReport.Name = "btnExportWeeklyReport";
            btnExportWeeklyReport.Size = new Size(403, 44);
            btnExportWeeklyReport.TabIndex = 21;
            btnExportWeeklyReport.Text = "匯出";
            btnExportWeeklyReport.UseVisualStyleBackColor = true;
            btnExportWeeklyReport.Click += btnExportWeeklyReport_Click;
            // 
            // btnStatistics
            // 
            btnStatistics.Dock = DockStyle.Fill;
            btnStatistics.Font = new Font("標楷體", 21.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnStatistics.Location = new Point(0, 0);
            btnStatistics.Margin = new Padding(0);
            btnStatistics.Name = "btnStatistics";
            btnStatistics.Size = new Size(403, 44);
            btnStatistics.TabIndex = 20;
            btnStatistics.Text = "統計";
            btnStatistics.UseVisualStyleBackColor = true;
            btnStatistics.Click += btnsStatistics_Click;
            // 
            // FoodLogForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 192);
            ClientSize = new Size(984, 561);
            Controls.Add(tableLayoutPanel5);
            Controls.Add(tableLayoutPanel4);
            Controls.Add(labelAccount);
            Controls.Add(label6);
            Font = new Font("Microsoft JhengHei UI", 9F, FontStyle.Regular, GraphicsUnit.Point, 136);
            Name = "FoodLogForm";
            Text = "紀錄飲食";
            Load += FoodLogForm_Load;
            groupBox1.ResumeLayout(false);
            tableLayoutPanel1.ResumeLayout(false);
            tableLayoutPanel1.PerformLayout();
            groupBox2.ResumeLayout(false);
            tableLayoutPanel2.ResumeLayout(false);
            tableLayoutPanel2.PerformLayout();
            tableLayoutPanel4.ResumeLayout(false);
            tableLayoutPanel3.ResumeLayout(false);
            tableLayoutPanel5.ResumeLayout(false);
            tableLayoutPanel6.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private RadioButton radioMorning;
        private GroupBox groupBox2;
        private TextBox txtNote;
        private TextBox txtFoodName;
        private Label lblFoodName1;
        private RadioButton radioOther;
        private RadioButton radioSupper;
        private RadioButton radioDinner;
        private RadioButton radioLunch;
        private ListBox listBox1;
        private Label label6;
        private TableLayoutPanel tableLayoutPanel1;
        private Label labelAccount;
        private TextBox txtOther;
        private Button buttonBack2;
        private TableLayoutPanel tableLayoutPanel2;
        private Label lblNote;
        private TableLayoutPanel tableLayoutPanel4;
        private Button btnSaveRecord;
        private TableLayoutPanel tableLayoutPanel3;
        private ComboBox comboBoxDaySelector;
        private Button btnDeleteRecord;
        private TableLayoutPanel tableLayoutPanel5;
        private Button btnStatistics;
        private TableLayoutPanel tableLayoutPanel6;
        private Button btnExportWeeklyReport;
    }
}