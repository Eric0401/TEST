﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using static 專題_食物相剋系統.Form1;

namespace 專題_食物相剋系統
{
    public partial class StatisticsForm : Form
    {
        private FormResizer resizer = new FormResizer();
        private string accountName;
        public StatisticsForm(string account)
        {
            InitializeComponent();
            this.Load += StatisticsForm_Load;
            this.Resize += StatisticsForm_Resize;
            accountName = account;
            LoadRecordsJson();
            LoadMealStatistics();
            LoadFoodStatistics();
            LoadWeekdayStatistics();
            LoadEmptyDays();
        }
        private void StatisticsForm_Load(object sender, EventArgs e)
        {
            resizer.CaptureOriginal(this);
        }
        private void StatisticsForm_Resize(object sender, EventArgs e)
        {
            resizer.ResizeAll(this);
        }
        private void groupBox1_Paint(object sender, PaintEventArgs e)// 消除虛線
        {
            GroupBox box = (GroupBox)sender;
            e.Graphics.Clear(box.BackColor); // 清除預設樣式
            TextRenderer.DrawText(e.Graphics, box.Text, box.Font, new Point(8, 0), box.ForeColor); // 自行畫文字
        }
        private void LoadRecordsJson()//載入所有帳號的紀錄資料（從 records.json 檔案讀入）
        {
            string path = Path.Combine(Application.StartupPath, "records.json");

            if (File.Exists(path))
            {
                string json = File.ReadAllText(path, Encoding.UTF8);
                records = JsonSerializer.Deserialize<Dictionary<string, List<Form1.Record>>>(json);
            }
            else
            {
                records = new Dictionary<string, List<Form1.Record>>();
            }
        }
        private void LoadMealStatistics()//listBoxMeal的內容
        {
            // 如果沒有這個帳號的資料就離開
            if (!records.ContainsKey(accountName)) return;

            var data = records[accountName];

            // 分組統計每個餐別出現次數
            var mealStats = data
                .GroupBy(r => r.餐別)
                .ToDictionary(g => g.Key, g => g.Count());

            // 顯示統計結果
            listBoxMeal.Items.Clear();
            foreach (var item in mealStats)
            {
                listBoxMeal.Items.Add($"{item.Key}：{item.Value} 次");
            }
        }
        private void LoadFoodStatistics()//listBoxFood的內容
        {
            // 如果沒有這個帳號的資料就離開
            if (!records.ContainsKey(accountName)) return;

            var data = records[accountName];

            // 對所有記錄做分組：依照「食物名稱」統計出現次數
            var foodStats = data
                .GroupBy(r => r.食物)
                .ToDictionary(g => g.Key, g => g.Count());

            // 顯示統計結果
            listBoxFood.Items.Clear();
            foreach (var item in foodStats.OrderByDescending(f => f.Value))
            {
                listBoxFood.Items.Add($"{item.Key}：{item.Value} 次");
            }
        }
        private void LoadWeekdayStatistics()//listBoxWeekday的內容
        {
            if (!Form1.records.ContainsKey(accountName)) return;

            var data = Form1.records[accountName];

            // 對所有紀錄按照「星期」分組，統計出現次數
            var weekdayStats = data
                .GroupBy(r => r.星期)
                .ToDictionary(g => g.Key, g => g.Count());

            listBoxWeekday.Items.Clear();

            if (weekdayStats.Count == 0)
            {
                listBoxWeekday.Items.Add("目前無統計資料");
            }
            else
            {
                // 順序自定義（星期一～日）
                string[] weekdayOrder = { "一", "二", "三", "四", "五", "六", "日" };

                foreach (var w in weekdayOrder)
                {
                    if (weekdayStats.ContainsKey(w))
                    {
                        listBoxWeekday.Items.Add($"星期{w}：{weekdayStats[w]} 次");
                    }
                }

                if (listBoxWeekday.Items.Count == 0)
                {
                    listBoxWeekday.Items.Add("目前無統計資料");
                }
            }
        }
        private void LoadEmptyDays()//listBoxEmptyDays的內容
        {
            if (!Form1.records.ContainsKey(accountName))
            {
                listBoxEmptyDays.Items.Clear();
                listBoxEmptyDays.Items.Add("找不到帳號紀錄！");
                return;
            }

            var data = Form1.records[accountName];

            // 取得帳號填過的所有日期（yyyy-MM-dd）
            var recordedDates = data
                .Select(r => r.日期)
                .Distinct()
                .ToHashSet();

            listBoxEmptyDays.Items.Clear();

            // 正確區間：從上週日到本週六
            DateTime today = DateTime.Today;
            int todayDay = (int)today.DayOfWeek;
            DateTime thisSunday = today.AddDays(-todayDay);        // 本週日
            DateTime lastSunday = thisSunday.AddDays(-7);          // 上週日

            for (int i = 0; i < 14; i++)
            {
                DateTime date = lastSunday.AddDays(i);             // 遞增跑這14天
                string dateStr = date.ToString("yyyy-MM-dd");

                if (!recordedDates.Contains(dateStr))
                {
                    string weekday = "日一二三四五六"[(int)date.DayOfWeek].ToString();
                    listBoxEmptyDays.Items.Add($"{dateStr}（星期{weekday}）");
                }
            }

            if (listBoxEmptyDays.Items.Count == 0)
            {
                listBoxEmptyDays.Items.Add("本週與上週都有填寫！");
            }
        }



        private void btnBack_Click(object sender, EventArgs e)
        {
            Form1 mainForm = Application.OpenForms["FoodLogForm"] as Form1;
            if (mainForm != null)
            {
                mainForm.Show(); // 顯示主畫面
            }
            this.Close();
        }
        private void LoadStatistics()
        {
            LoadMealStatistics();        // 餐別統計
            LoadFoodStatistics();        // 食物統計
            LoadWeekdayStatistics();     // 星期幾統計
            LoadEmptyDays();             // 空白日期
        }
        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadRecordsJson();     // 重新從檔案載入最新資料
            LoadStatistics();
            LoadFoodStatistics();
            LoadWeekdayStatistics();
            LoadEmptyDays();
        }

        
    }
}
