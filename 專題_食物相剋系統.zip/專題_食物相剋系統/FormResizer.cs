﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;
using WinFormsTimer = System.Windows.Forms.Timer;

namespace 專題_食物相剋系統
{
    internal class FormResizer
    {
        private Dictionary<Control, Rectangle> originalBounds = new();
        private Dictionary<Control, float> originalFontSizes = new();
        private Dictionary<Control, Font> scaledFonts = new();
        private Size originalFormSize;
        private WinFormsTimer resizeTimer = new();
        private Control pendingRoot = null;

        public FormResizer()
        {
            resizeTimer.Interval = 100;
            resizeTimer.Tick += (s, e) =>
            {
                resizeTimer.Stop();
                if (pendingRoot != null)
                {
                    ResizeAllNow(pendingRoot);
                }
            };
        }

        // 呼叫一次，記住初始狀態
        public void CaptureOriginal(Control root)
        {
            originalFormSize = root.Size;
            originalBounds.Clear();
            originalFontSizes.Clear();
            scaledFonts.Clear();
            SaveBounds(root);
        }

        // 外部呼叫：延遲實際執行縮放以避免過度觸發
        public void ResizeAll(Control root)
        {
            pendingRoot = root;
            resizeTimer.Stop();
            resizeTimer.Start();
        }

        // 真正執行縮放
        private void ResizeAllNow(Control root)
        {
            float scaleX = (float)root.Width / originalFormSize.Width;
            float scaleY = (float)root.Height / originalFormSize.Height;
            ResizeControls(root, scaleX, scaleY);
        }

        private void SaveBounds(Control parent)
        {
            foreach (Control ctrl in parent.Controls)
            {
                originalBounds[ctrl] = ctrl.Bounds;
                originalFontSizes[ctrl] = ctrl.Font.Size;

                if (ctrl.HasChildren)
                    SaveBounds(ctrl);
            }
        }
        public void CaptureOriginalControl(Control ctrl)
        {
            if (!originalBounds.ContainsKey(ctrl))
            {
                originalBounds[ctrl] = ctrl.Bounds;
                originalFontSizes[ctrl] = ctrl.Font.Size;
            }
        }
        private void ResizeControls(Control parent, float scaleX, float scaleY)
        {
            foreach (Control ctrl in parent.Controls)
            {
                if (originalBounds.ContainsKey(ctrl))
                {
                    Rectangle original = originalBounds[ctrl];
                    ctrl.Left = (int)(original.Left * scaleX);
                    ctrl.Top = (int)(original.Top * scaleY);
                    ctrl.Width = (int)(original.Width * scaleX);
                    ctrl.Height = (int)(original.Height * scaleY);

                    float originalFontSize = originalFontSizes[ctrl];
                    float scaledFontSize = originalFontSize * Math.Min(scaleX, scaleY);

                    if (!scaledFonts.ContainsKey(ctrl) || Math.Abs(scaledFonts[ctrl].Size - scaledFontSize) > 0.1f)
                    {
                        if (scaledFonts.ContainsKey(ctrl))
                        {
                            scaledFonts[ctrl].Dispose();
                            scaledFonts.Remove(ctrl);
                        }

                        Font newFont = new Font(ctrl.Font.FontFamily, scaledFontSize, ctrl.Font.Style);
                        ctrl.Font = newFont;
                        scaledFonts[ctrl] = newFont;
                    }
                }

                if (ctrl.HasChildren)
                    ResizeControls(ctrl, scaleX, scaleY);
            }
        }
    }
}
