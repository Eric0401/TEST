﻿using System;
using System.Windows.Forms;

namespace 專題_食物相剋系統
{
    // 訪客模式，繼承 AccountForm，限定功能更嚴格
    public partial class GuestForm : AccountForm
    {
        // 建構子：傳入固定帳號名稱 "訪客"
        public GuestForm() : base("訪客")
        {
            InitializeComponent();
            // 使用獨立載入事件，避免覆寫 AccountForm_Load
            this.Load += GuestForm_Load;
        }

        // 訪客專用載入事件，呼叫父類初始化，並更改身份顯示
        private void GuestForm_Load(object sender, EventArgs e)
        {
            base.AccountForm_Load(sender, e); // 呼叫父類載入邏輯
            labelAccount.Text = "身份：訪客（僅能查詢）"; // 顯示訪客身份文字
        }

        // 禁止訪客新增資料，覆寫父類新增事件，彈出提示
        protected override void buttonProvide_Click(object sender, EventArgs e)
        {
            MessageBox.Show("訪客無法新增資料！");
        }

        // 禁止訪客記錄資料，覆寫父類記錄事件，彈出提示
        protected override void buttonEat_Click(object sender, EventArgs e)
        {
            MessageBox.Show("訪客無法記錄資料！");
        }
    }
}
