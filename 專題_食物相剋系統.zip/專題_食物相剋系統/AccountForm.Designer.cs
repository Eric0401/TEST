﻿namespace 專題_食物相剋系統
{
    partial class AccountForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelAccount = new Label();
            btnPotato = new Button();
            btnCucumber = new Button();
            btnTomato = new Button();
            btnGreenOnion = new Button();
            btnHoney = new Button();
            btnGarlic = new Button();
            btnSpinach = new Button();
            btnSoybean = new Button();
            btnPorkBlood = new Button();
            btnKelp = new Button();
            btnOrange = new Button();
            btnMilk = new Button();
            btnBanana = new Button();
            btnCarrot = new Button();
            btnApple = new Button();
            textBox1 = new TextBox();
            buttonSearch = new Button();
            buttonProvide = new Button();
            buttonSignout = new Button();
            tableLayoutPanel1 = new TableLayoutPanel();
            buttonEat = new Button();
            groupBox1 = new GroupBox();
            txtList = new TextBox();
            btnSendEmail = new Button();
            scrollPanel = new Panel();
            tableLayoutPanelFood = new TableLayoutPanel();
            tableLayoutPanel1.SuspendLayout();
            groupBox1.SuspendLayout();
            scrollPanel.SuspendLayout();
            tableLayoutPanelFood.SuspendLayout();
            SuspendLayout();
            // 
            // labelAccount
            // 
            labelAccount.AutoSize = true;
            labelAccount.BackColor = Color.Cornsilk;
            labelAccount.Font = new Font("標楷體", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            labelAccount.Location = new Point(89, 62);
            labelAccount.Name = "labelAccount";
            labelAccount.Size = new Size(110, 27);
            labelAccount.TabIndex = 0;
            labelAccount.Text = "帳號： ";
            // 
            // btnPotato
            // 
            btnPotato.Anchor = AnchorStyles.None;
            btnPotato.Font = new Font("標楷體", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnPotato.Location = new Point(249, 327);
            btnPotato.Name = "btnPotato";
            btnPotato.Size = new Size(75, 75);
            btnPotato.TabIndex = 14;
            btnPotato.Text = "馬鈴薯";
            btnPotato.UseVisualStyleBackColor = true;
            // 
            // btnCucumber
            // 
            btnCucumber.Anchor = AnchorStyles.None;
            btnCucumber.Font = new Font("標楷體", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnCucumber.Location = new Point(134, 327);
            btnCucumber.Name = "btnCucumber";
            btnCucumber.Size = new Size(75, 75);
            btnCucumber.TabIndex = 13;
            btnCucumber.Text = "黃瓜";
            btnCucumber.UseVisualStyleBackColor = true;
            // 
            // btnTomato
            // 
            btnTomato.Anchor = AnchorStyles.None;
            btnTomato.Font = new Font("標楷體", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnTomato.Location = new Point(19, 327);
            btnTomato.Name = "btnTomato";
            btnTomato.Size = new Size(75, 75);
            btnTomato.TabIndex = 12;
            btnTomato.Text = "蕃茄";
            btnTomato.UseVisualStyleBackColor = true;
            // 
            // btnGreenOnion
            // 
            btnGreenOnion.Anchor = AnchorStyles.None;
            btnGreenOnion.Font = new Font("標楷體", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnGreenOnion.Location = new Point(249, 246);
            btnGreenOnion.Name = "btnGreenOnion";
            btnGreenOnion.Size = new Size(75, 75);
            btnGreenOnion.TabIndex = 11;
            btnGreenOnion.Text = "大蔥";
            btnGreenOnion.UseVisualStyleBackColor = true;
            // 
            // btnHoney
            // 
            btnHoney.Anchor = AnchorStyles.None;
            btnHoney.Font = new Font("標楷體", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnHoney.Location = new Point(134, 246);
            btnHoney.Name = "btnHoney";
            btnHoney.Size = new Size(75, 75);
            btnHoney.TabIndex = 10;
            btnHoney.Text = "蜂蜜";
            btnHoney.UseVisualStyleBackColor = true;
            // 
            // btnGarlic
            // 
            btnGarlic.Anchor = AnchorStyles.None;
            btnGarlic.Font = new Font("標楷體", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnGarlic.Location = new Point(19, 246);
            btnGarlic.Name = "btnGarlic";
            btnGarlic.Size = new Size(75, 75);
            btnGarlic.TabIndex = 9;
            btnGarlic.Text = "大蒜";
            btnGarlic.UseVisualStyleBackColor = true;
            // 
            // btnSpinach
            // 
            btnSpinach.Anchor = AnchorStyles.None;
            btnSpinach.Font = new Font("標楷體", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnSpinach.Location = new Point(249, 165);
            btnSpinach.Name = "btnSpinach";
            btnSpinach.Size = new Size(75, 75);
            btnSpinach.TabIndex = 8;
            btnSpinach.Text = "菠菜";
            btnSpinach.UseVisualStyleBackColor = true;
            // 
            // btnSoybean
            // 
            btnSoybean.Anchor = AnchorStyles.None;
            btnSoybean.Font = new Font("標楷體", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnSoybean.Location = new Point(134, 165);
            btnSoybean.Name = "btnSoybean";
            btnSoybean.Size = new Size(75, 75);
            btnSoybean.TabIndex = 7;
            btnSoybean.Text = "黃豆";
            btnSoybean.UseVisualStyleBackColor = true;
            // 
            // btnPorkBlood
            // 
            btnPorkBlood.Anchor = AnchorStyles.None;
            btnPorkBlood.Font = new Font("標楷體", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnPorkBlood.Location = new Point(19, 165);
            btnPorkBlood.Name = "btnPorkBlood";
            btnPorkBlood.Size = new Size(75, 75);
            btnPorkBlood.TabIndex = 6;
            btnPorkBlood.Text = "豬血";
            btnPorkBlood.UseVisualStyleBackColor = true;
            // 
            // btnKelp
            // 
            btnKelp.Anchor = AnchorStyles.None;
            btnKelp.Font = new Font("標楷體", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnKelp.Location = new Point(249, 84);
            btnKelp.Name = "btnKelp";
            btnKelp.Size = new Size(75, 75);
            btnKelp.TabIndex = 5;
            btnKelp.Text = "海帶";
            btnKelp.UseVisualStyleBackColor = true;
            // 
            // btnOrange
            // 
            btnOrange.Anchor = AnchorStyles.None;
            btnOrange.Font = new Font("標楷體", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnOrange.Location = new Point(134, 84);
            btnOrange.Name = "btnOrange";
            btnOrange.Size = new Size(75, 75);
            btnOrange.TabIndex = 4;
            btnOrange.Text = "橘子";
            btnOrange.UseVisualStyleBackColor = true;
            // 
            // btnMilk
            // 
            btnMilk.Anchor = AnchorStyles.None;
            btnMilk.Font = new Font("標楷體", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnMilk.Location = new Point(19, 84);
            btnMilk.Name = "btnMilk";
            btnMilk.Size = new Size(75, 75);
            btnMilk.TabIndex = 3;
            btnMilk.Text = "牛奶";
            btnMilk.UseVisualStyleBackColor = true;
            // 
            // btnBanana
            // 
            btnBanana.Anchor = AnchorStyles.None;
            btnBanana.Font = new Font("標楷體", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnBanana.Location = new Point(249, 3);
            btnBanana.Name = "btnBanana";
            btnBanana.Size = new Size(75, 75);
            btnBanana.TabIndex = 2;
            btnBanana.Text = "香蕉";
            btnBanana.UseVisualStyleBackColor = true;
            // 
            // btnCarrot
            // 
            btnCarrot.Anchor = AnchorStyles.None;
            btnCarrot.Font = new Font("標楷體", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnCarrot.Location = new Point(134, 3);
            btnCarrot.Name = "btnCarrot";
            btnCarrot.Size = new Size(75, 75);
            btnCarrot.TabIndex = 1;
            btnCarrot.Text = "胡蘿蔔";
            btnCarrot.UseVisualStyleBackColor = true;
            // 
            // btnApple
            // 
            btnApple.Anchor = AnchorStyles.None;
            btnApple.Font = new Font("標楷體", 12F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnApple.Location = new Point(19, 3);
            btnApple.Name = "btnApple";
            btnApple.Size = new Size(75, 75);
            btnApple.TabIndex = 0;
            btnApple.Text = "蘋果";
            btnApple.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("標楷體", 18F, FontStyle.Regular, GraphicsUnit.Point, 136);
            textBox1.Location = new Point(518, 118);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(258, 36);
            textBox1.TabIndex = 3;
            textBox1.KeyDown += textBox1_KeyDown;
            // 
            // buttonSearch
            // 
            buttonSearch.BackColor = Color.White;
            buttonSearch.Font = new Font("標楷體", 18F, FontStyle.Regular, GraphicsUnit.Point, 136);
            buttonSearch.Location = new Point(721, 71);
            buttonSearch.Name = "buttonSearch";
            buttonSearch.Size = new Size(94, 39);
            buttonSearch.TabIndex = 4;
            buttonSearch.Text = "查詢";
            buttonSearch.UseVisualStyleBackColor = false;
            buttonSearch.Click += buttonSearch_Click;
            // 
            // buttonProvide
            // 
            buttonProvide.Anchor = AnchorStyles.None;
            buttonProvide.Font = new Font("標楷體", 18F, FontStyle.Regular, GraphicsUnit.Point, 136);
            buttonProvide.Location = new Point(6, 0);
            buttonProvide.Margin = new Padding(0);
            buttonProvide.Name = "buttonProvide";
            buttonProvide.Size = new Size(172, 39);
            buttonProvide.TabIndex = 5;
            buttonProvide.Text = "資料更新";
            buttonProvide.UseVisualStyleBackColor = true;
            buttonProvide.Click += buttonProvide_Click;
            // 
            // buttonSignout
            // 
            buttonSignout.BackColor = Color.White;
            buttonSignout.Font = new Font("標楷體", 18F, FontStyle.Regular, GraphicsUnit.Point, 136);
            buttonSignout.Location = new Point(721, 22);
            buttonSignout.Name = "buttonSignout";
            buttonSignout.Size = new Size(94, 39);
            buttonSignout.TabIndex = 6;
            buttonSignout.Text = "登出";
            buttonSignout.UseVisualStyleBackColor = false;
            buttonSignout.Click += btnsignout_Click;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.BackColor = Color.Cornsilk;
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Controls.Add(buttonEat, 1, 0);
            tableLayoutPanel1.Controls.Add(buttonProvide, 0, 0);
            tableLayoutPanel1.Location = new Point(95, 117);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Size = new Size(370, 39);
            tableLayoutPanel1.TabIndex = 7;
            // 
            // buttonEat
            // 
            buttonEat.Anchor = AnchorStyles.None;
            buttonEat.Font = new Font("標楷體", 18F, FontStyle.Regular, GraphicsUnit.Point, 136);
            buttonEat.Location = new Point(191, 0);
            buttonEat.Margin = new Padding(0);
            buttonEat.Name = "buttonEat";
            buttonEat.Size = new Size(172, 39);
            buttonEat.TabIndex = 6;
            buttonEat.Text = "飲食紀錄";
            buttonEat.UseVisualStyleBackColor = true;
            buttonEat.Click += buttonEat_Click;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Cornsilk;
            groupBox1.Controls.Add(txtList);
            groupBox1.Controls.Add(btnSendEmail);
            groupBox1.Controls.Add(scrollPanel);
            groupBox1.Controls.Add(buttonSignout);
            groupBox1.Controls.Add(buttonSearch);
            groupBox1.Location = new Point(73, 46);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(835, 450);
            groupBox1.TabIndex = 8;
            groupBox1.TabStop = false;
            groupBox1.Paint += groupBox1_Paint;
            // 
            // txtList
            // 
            txtList.Font = new Font("標楷體", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtList.Location = new Point(446, 117);
            txtList.Multiline = true;
            txtList.Name = "txtList";
            txtList.ReadOnly = true;
            txtList.ScrollBars = ScrollBars.Vertical;
            txtList.Size = new Size(369, 271);
            txtList.TabIndex = 11;
            // 
            // btnSendEmail
            // 
            btnSendEmail.Font = new Font("標楷體", 18F, FontStyle.Regular, GraphicsUnit.Point, 136);
            btnSendEmail.Location = new Point(445, 394);
            btnSendEmail.Margin = new Padding(0);
            btnSendEmail.Name = "btnSendEmail";
            btnSendEmail.Size = new Size(370, 35);
            btnSendEmail.TabIndex = 10;
            btnSendEmail.Text = "寄送Email";
            btnSendEmail.UseVisualStyleBackColor = true;
            btnSendEmail.Click += btnSendEmail_Click;
            // 
            // scrollPanel
            // 
            scrollPanel.AutoScroll = true;
            scrollPanel.BorderStyle = BorderStyle.FixedSingle;
            scrollPanel.Controls.Add(tableLayoutPanelFood);
            scrollPanel.Location = new Point(28, 116);
            scrollPanel.Name = "scrollPanel";
            scrollPanel.Size = new Size(364, 313);
            scrollPanel.TabIndex = 9;
            // 
            // tableLayoutPanelFood
            // 
            tableLayoutPanelFood.AutoScroll = true;
            tableLayoutPanelFood.AutoSize = true;
            tableLayoutPanelFood.ColumnCount = 3;
            tableLayoutPanelFood.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333321F));
            tableLayoutPanelFood.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333359F));
            tableLayoutPanelFood.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 33.3333359F));
            tableLayoutPanelFood.Controls.Add(btnPotato, 2, 4);
            tableLayoutPanelFood.Controls.Add(btnApple, 0, 0);
            tableLayoutPanelFood.Controls.Add(btnCucumber, 1, 4);
            tableLayoutPanelFood.Controls.Add(btnCarrot, 1, 0);
            tableLayoutPanelFood.Controls.Add(btnTomato, 0, 4);
            tableLayoutPanelFood.Controls.Add(btnBanana, 2, 0);
            tableLayoutPanelFood.Controls.Add(btnGreenOnion, 2, 3);
            tableLayoutPanelFood.Controls.Add(btnMilk, 0, 1);
            tableLayoutPanelFood.Controls.Add(btnHoney, 1, 3);
            tableLayoutPanelFood.Controls.Add(btnOrange, 1, 1);
            tableLayoutPanelFood.Controls.Add(btnGarlic, 0, 3);
            tableLayoutPanelFood.Controls.Add(btnKelp, 2, 1);
            tableLayoutPanelFood.Controls.Add(btnSpinach, 2, 2);
            tableLayoutPanelFood.Controls.Add(btnPorkBlood, 0, 2);
            tableLayoutPanelFood.Controls.Add(btnSoybean, 1, 2);
            tableLayoutPanelFood.Dock = DockStyle.Top;
            tableLayoutPanelFood.Location = new Point(0, 0);
            tableLayoutPanelFood.Name = "tableLayoutPanelFood";
            tableLayoutPanelFood.RowCount = 5;
            tableLayoutPanelFood.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanelFood.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanelFood.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanelFood.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanelFood.RowStyles.Add(new RowStyle(SizeType.Percent, 20F));
            tableLayoutPanelFood.Size = new Size(345, 405);
            tableLayoutPanelFood.TabIndex = 8;
            // 
            // AccountForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 192);
            ClientSize = new Size(984, 561);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(textBox1);
            Controls.Add(labelAccount);
            Controls.Add(groupBox1);
            Name = "AccountForm";
            Text = "相剋查詢";
            Load += AccountForm_Load;
            tableLayoutPanel1.ResumeLayout(false);
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            scrollPanel.ResumeLayout(false);
            scrollPanel.PerformLayout();
            tableLayoutPanelFood.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        protected Label labelAccount;
        private Button btnApple;
        private Button btnPorkBlood;
        private Button btnKelp;
        private Button btnOrange;
        private Button btnMilk;
        private Button btnBanana;
        private Button btnCarrot;
        private Button btnPotato;
        private Button btnCucumber;
        private Button btnTomato;
        private Button btnGreenOnion;
        private Button btnHoney;
        private Button btnGarlic;
        private Button btnSpinach;
        private Button btnSoybean;
        protected TextBox textBox1;
        protected Button buttonSearch;
        protected Button buttonProvide;
        protected Button buttonSignout;
        private TableLayoutPanel tableLayoutPanel1;
        protected Button buttonEat;
        private GroupBox groupBox1;
        private TableLayoutPanel tableLayoutPanelFood;
        private Panel scrollPanel;
        private Button btnSendEmail;
        private TextBox txtList;
    }
}