﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace 專題_食物相剋系統
{
    public partial class AccountForm : Form
    {
        private string selectedFoodName = null;
        private FormResizer resizer = new FormResizer();
        private string accountName;

        // 儲存原始按鈕文字，用於恢復圖片後還原
        private Dictionary<Button, string> originalButtonTexts = new();

        // 圖片快取（避免重複加載 + 釋放資源）
        private Dictionary<string, Image> imageCache = new();

        public AccountForm(string account)
        {
            InitializeComponent();
            this.Load += AccountForm_Load;
            this.Resize += AccountForm_Resize;
            accountName = account;
        }

        protected AccountForm() : this("訪客") { }

        protected virtual void AccountForm_Load(object sender, EventArgs e)
        {
            resizer.CaptureOriginal(this);
            labelAccount.Text = "帳號： " + accountName;

            // 綁定所有 btn 開頭按鈕的事件
            foreach (Control ctrl in tableLayoutPanelFood.Controls)
            {
                if (ctrl is Button btn && btn.Name.StartsWith("btn"))
                {
                    originalButtonTexts[btn] = btn.Text;
                    btn.Click += FoodButton_Click;
                    btn.MouseEnter += FoodButton_MouseEnter;
                    btn.MouseLeave += FoodButton_MouseLeave;
                }
            }
        }

        private void AccountForm_Resize(object sender, EventArgs e)
        {
            resizer.ResizeAll(this);
        }

        protected virtual void btnsignout_Click(object sender, EventArgs e)
        {
            Form1 mainForm = Application.OpenForms["Form1"] as Form1;
            if (mainForm != null) mainForm.Show();
            this.Close();
        }

        protected virtual void FoodButton_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn == null || !originalButtonTexts.ContainsKey(btn)) return;

            string foodName = originalButtonTexts[btn];
            selectedFoodName = foodName;
            txtList.Clear();

            if (Form1.foodInfo.ContainsKey(foodName))
            {
                var data = Form1.foodInfo[foodName];
                txtList.AppendText($"食物：{foodName}\r\n");
                txtList.AppendText($"優點：{string.Join("、", data.優點)}\r\n");
                txtList.AppendText($"相剋：{string.Join("、", data.相剋)}\r\n");
                txtList.AppendText($"後果：{data.後果}\r\n");
                txtList.AppendText($"解決辦法：{data.解決辦法}\r\n");
            }
            else
            {
                txtList.AppendText("查無資料");
            }
        }

        protected virtual void buttonSearch_Click(object sender, EventArgs e)
        {
            string keyword = textBox1.Text.Trim();
            txtList.Clear();

            if (string.IsNullOrEmpty(keyword))
            {
                txtList.AppendText("請輸入食物名稱");
                return;
            }

            if (Form1.foodInfo.ContainsKey(keyword))
            {
                var data = Form1.foodInfo[keyword];
                txtList.AppendText($"食物：{keyword}\r\n");
                txtList.AppendText($"優點：{string.Join(", ", data.優點)}\r\n");
                txtList.AppendText($"相剋：{string.Join(", ", data.相剋)}\r\n");
                txtList.AppendText($"後果：{data.後果}\r\n");
                txtList.AppendText($"解決辦法：{data.解決辦法}\r\n");
                selectedFoodName = keyword;
            }
            else
            {
                txtList.AppendText("查無此食物，請自行新增");
                selectedFoodName = null;
            }
        }

        protected virtual void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                buttonSearch.PerformClick();
                e.SuppressKeyPress = true;
            }
        }

        protected virtual void buttonProvide_Click(object sender, EventArgs e)
        {
            ProvideForm pf = new ProvideForm();
            pf.Show();
        }

        protected virtual void buttonEat_Click(object sender, EventArgs e)
        {
            FoodLogForm flf = new FoodLogForm(accountName);
            flf.Show();
        }

        // 滑入按鈕：載入圖片 + 隱藏文字
        private void FoodButton_MouseEnter(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn == null || !originalButtonTexts.ContainsKey(btn)) return;

            string foodName = originalButtonTexts[btn];
            string imagePath = $"Resources\\{foodName}.jpg";

            // 如果快取中沒有，則載入圖檔（並複製一份到記憶體中避免檔案鎖定）
            if (!imageCache.ContainsKey(foodName) && File.Exists(imagePath))
            {
                using var fs = new FileStream(imagePath, FileMode.Open, FileAccess.Read);
                imageCache[foodName] = new Bitmap(fs); // 使用 Bitmap 複製進記憶體
            }

            // 套用圖片
            if (imageCache.ContainsKey(foodName))
            {
                btn.BackgroundImage = imageCache[foodName];
                btn.BackgroundImageLayout = ImageLayout.Zoom;
                btn.Text = ""; // 隱藏文字
            }
        }

        // 滑出按鈕：移除圖片 + 還原文字
        private void FoodButton_MouseLeave(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn == null || !originalButtonTexts.ContainsKey(btn)) return;

            btn.BackgroundImage = null;
            btn.Text = originalButtonTexts[btn];
        }

        // 自訂繪製 GroupBox 邊框（去除虛線）
        protected virtual void groupBox1_Paint(object sender, PaintEventArgs e)
        {
            GroupBox box = (GroupBox)sender;
            e.Graphics.Clear(box.BackColor);
            using var borderPen = new Pen(Color.Black, 1);
            e.Graphics.DrawRectangle(borderPen, 0, 0, box.Width - 1, box.Height - 1);
        }

        // 可選擇釋放所有載入的圖片（例如在 Form 關閉時）
        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            foreach (var img in imageCache.Values)
                img.Dispose();
            imageCache.Clear();

            base.OnFormClosed(e);
        }
        public void AddFoodButtonAtFront(string foodName)
        {
            // 建立新按鈕
            Button newBtn = new Button
            {
                Text = foodName,
                Font = new Font("標楷體", 12F, FontStyle.Regular),
                Size = new Size(75, 75),
                Anchor = AnchorStyles.None,
                UseVisualStyleBackColor = true
            };

            // 綁定事件
            newBtn.Click += FoodButton_Click;
            newBtn.MouseEnter += FoodButton_MouseEnter;
            newBtn.MouseLeave += FoodButton_MouseLeave;

            // 新增到 tableLayoutPanelFood，最前面插入
            // 先將現有所有控制項往後移動一格
            for (int i = tableLayoutPanelFood.Controls.Count - 1; i >= 0; i--)
            {
                Control ctrl = tableLayoutPanelFood.Controls[i];
                int col = tableLayoutPanelFood.GetColumn(ctrl);
                int row = tableLayoutPanelFood.GetRow(ctrl);

                int index = row * tableLayoutPanelFood.ColumnCount + col + 1;
                int newRow = index / tableLayoutPanelFood.ColumnCount;
                int newCol = index % tableLayoutPanelFood.ColumnCount;

                tableLayoutPanelFood.SetRow(ctrl, newRow);
                tableLayoutPanelFood.SetColumn(ctrl, newCol);
            }

            // 將新按鈕放到 (0,0)
            tableLayoutPanelFood.Controls.Add(newBtn, 0, 0);

            // 如果超過目前行數，調整行數
            int totalButtons = tableLayoutPanelFood.Controls.Count;
            int neededRows = (int)Math.Ceiling(totalButtons / (double)tableLayoutPanelFood.ColumnCount);
            if (neededRows > tableLayoutPanelFood.RowCount)
            {
                tableLayoutPanelFood.RowCount = neededRows;
                for (int i = tableLayoutPanelFood.RowStyles.Count; i < neededRows; i++)
                {
                    tableLayoutPanelFood.RowStyles.Add(new RowStyle(SizeType.Percent, 100f / neededRows));
                }
            }

            // 同時將文字記錄在字典，方便事件判斷
            originalButtonTexts[newBtn] = foodName;

            resizer.CaptureOriginalControl(newBtn);
        }
        private HashSet<string> defaultFoodButtons = new HashSet<string>()
            {
                "蘋果", "豬血", "海帶", "橘子", "牛奶", "香蕉", "胡蘿蔔",
                "馬鈴薯", "黃瓜", "蕃茄", "大蔥", "蜂蜜", "大蒜", "菠菜", "黃豆"
            };

        public void RemoveFoodButton(string foodName)
        {
            if (defaultFoodButtons.Contains(foodName))
            {
                // 預設按鈕不刪除，只刪除資料
                return;
            }

            Button btnToRemove = null;
            foreach (Button btn in tableLayoutPanelFood.Controls.OfType<Button>())
            {
                if (btn.Text == foodName)
                {
                    btnToRemove = btn;
                    break;
                }
            }
            if (btnToRemove != null)
            {
                tableLayoutPanelFood.Controls.Remove(btnToRemove);
                originalButtonTexts.Remove(btnToRemove);
                btnToRemove.Dispose();

                // 重新排版
                RefreshFoodButtonsLayout();
            }
        }
        public void RefreshFoodButtonsLayout()
        {
            var buttons = tableLayoutPanelFood.Controls.OfType<Button>()
                             .OrderBy(btn => btn.TabIndex) // 或用你儲存的順序
                             .ToList();

            tableLayoutPanelFood.Controls.Clear();

            int colCount = tableLayoutPanelFood.ColumnCount;
            int row = 0;
            int col = 0;

            foreach (var btn in buttons)
            {
                tableLayoutPanelFood.Controls.Add(btn, col, row);
                col++;
                if (col >= colCount)
                {
                    col = 0;
                    row++;
                }
            }

            tableLayoutPanelFood.RowCount = row + 1;
        }
        private void btnSendEmail_Click_1(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(selectedFoodName))
            {
                EmailForm emailForm = new EmailForm(selectedFoodName);
                emailForm.ShowDialog();
            }
            else
            {
                MessageBox.Show("請先查詢並選擇一項食物。");
            }
        }
    }
}
