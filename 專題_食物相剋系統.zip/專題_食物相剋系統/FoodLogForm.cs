﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Windows.Forms;

namespace 專題_食物相剋系統
{
    public partial class FoodLogForm : Form
    {
        private FormResizer resizer = new FormResizer();
        private string accountName;  // 傳入的帳號名稱
        private Dictionary<string, List<Form1.Record>> records = new();
        private string currentAccount = "";

        public FoodLogForm(string account)
        {
            InitializeComponent();
            this.Load += FoodLogForm_Load;
            this.Resize += FoodLogForm_Resize;
            accountName = account;
            LoadRecordsJson();  // 載入飲食紀錄資料
        }

        // 表單載入：初始化UI，設置帳號，初始化日期下拉，預設選擇今天，更新列表顯示
        private void FoodLogForm_Load(object sender, EventArgs e)
        {
            resizer.CaptureOriginal(this);
            labelAccount.Text = "帳號： " + accountName;
            InitWeekSelector();
            currentAccount = accountName;

            string today = DateTime.Now.ToString("yyyy-MM-dd");
            for (int i = 0; i < comboBoxDaySelector.Items.Count; i++)
                if (comboBoxDaySelector.Items[i].ToString().Contains(today))
                {
                    comboBoxDaySelector.SelectedIndex = i;
                    break;
                }

            UpdateListBoxByDate(currentAccount);
        }

        // 表單大小變更時，調整所有控制項大小與位置
        private void FoodLogForm_Resize(object sender, EventArgs e)
            => resizer.ResizeAll(this);

        // 取得使用者選擇的餐別（早餐、午餐、晚餐、宵夜或自訂）
        private string GetSelectedMeal()
        {
            if (radioOther.Checked)
            {
                string other = txtOther.Text.Trim();
                return string.IsNullOrEmpty(other) ? null : other;
            }
            if (radioMorning.Checked) return "早餐";
            if (radioLunch.Checked) return "午餐";
            if (radioDinner.Checked) return "晚餐";
            if (radioSupper.Checked) return "宵夜";
            return null;
        }

        // 返回主畫面
        private void buttonBack2_Click(object sender, EventArgs e)
        {
            if (Application.OpenForms["AccountForm"] is Form mainForm)
                mainForm.Show();
            this.Close();
        }

        // 初始化下拉選單為「本週」與「上週」的日期標籤
        private void InitWeekSelector()
        {
            comboBoxDaySelector.Items.Clear();
            DateTime today = DateTime.Today;
            DateTime thisMonday = today.AddDays(-(int)today.DayOfWeek + 1);
            DateTime lastMonday = thisMonday.AddDays(-7);

            var allDates = new List<(DateTime date, string label)>();
            for (int i = 0; i < 7; i++)
            {
                DateTime dayThis = thisMonday.AddDays(i);
                DateTime dayLast = lastMonday.AddDays(i);
                allDates.Add((dayLast, $"上週 {dayLast:yyyy-MM-dd}（{dayLast:dddd}）"));
                allDates.Add((dayThis, $"本週 {dayThis:yyyy-MM-dd}（{dayThis:dddd}）"));
            }

            allDates = allDates.OrderBy(d => d.date).ToList();
            foreach (var item in allDates)
                comboBoxDaySelector.Items.Add(item.label);

            comboBoxDaySelector.SelectedIndex = 0;
        }

        // 從 JSON 檔案載入紀錄
        private void LoadRecordsJson()
        {
            string path = Path.Combine(Application.StartupPath, "records.json");
            if (File.Exists(path))
            {
                string json = File.ReadAllText(path, Encoding.UTF8);
                records = JsonSerializer.Deserialize<Dictionary<string, List<Form1.Record>>>(json);
            }
            else
            {
                records = new Dictionary<string, List<Form1.Record>>();
            }
        }

        // 根據選擇的日期過濾並更新 ListBox 顯示該日飲食紀錄
        private void UpdateListBoxByDate(string account)
        {
            if (!records.ContainsKey(account)) return;

            string selected = comboBoxDaySelector.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(selected)) return;

            int start = selected.IndexOf(' ') + 1;
            int end = selected.IndexOf('（');
            string dateStr = selected.Substring(start, end - start);

            listBox1.Items.Clear();

            var filtered = records[account].Where(r => r.日期 == dateStr).ToList();

            if (filtered.Count == 0)
                listBox1.Items.Add("當天無紀錄");
            else
                filtered.ForEach(r => listBox1.Items.Add(r));
        }

        // 消除 groupBox1 的虛線框線，改用自訂繪製文字
        private void groupBox1_Paint(object sender, PaintEventArgs e)
        {
            GroupBox box = (GroupBox)sender;
            e.Graphics.Clear(box.BackColor);
            TextRenderer.DrawText(e.Graphics, box.Text, box.Font, new Point(8, 0), box.ForeColor);
        }

        // 消除 groupBox2 虛線，改畫左右實線與文字
        private void groupBox2_Paint(object sender, PaintEventArgs e)
        {
            GroupBox box = (GroupBox)sender;
            e.Graphics.Clear(box.BackColor);
            using Pen pen = new Pen(Color.Black, 1);
            int topOffset = TextRenderer.MeasureText(box.Text, box.Font).Height / 2;

            e.Graphics.DrawLine(pen, 1, topOffset, 1, box.Height - 2);          // 左線
            e.Graphics.DrawLine(pen, box.Width - 2, topOffset, box.Width - 2, box.Height - 2); // 右線
            TextRenderer.DrawText(e.Graphics, box.Text, box.Font, new Point(8, 0), box.ForeColor);
        }

        // 儲存飲食紀錄按鈕：驗證、保留14天內紀錄、寫檔、更新UI
        private void btnSaveRecord_Click(object sender, EventArgs e)
        {
            string food = txtFoodName.Text.Trim();
            string note = txtNote.Text.Trim();
            string meal = GetSelectedMeal();

            if (string.IsNullOrEmpty(food) || string.IsNullOrEmpty(meal))
            {
                MessageBox.Show("請輸入食物並選擇餐別！");
                return;
            }

            string date = DateTime.Now.ToString("yyyy-MM-dd");
            string weekday = "一二三四五六日"[(int)DateTime.Now.DayOfWeek == 0 ? 6 : (int)DateTime.Now.DayOfWeek - 1].ToString();

            if (!Form1.records.ContainsKey(accountName))
                Form1.records[accountName] = new List<Form1.Record>();

            // 只保留最近14天的紀錄
            DateTime today = DateTime.Today;
            int offset = today.DayOfWeek == DayOfWeek.Sunday ? 6 : (int)today.DayOfWeek - 1;
            DateTime thisMonday = today.AddDays(-offset);
            DateTime lastMonday = thisMonday.AddDays(-7);

            Form1.records[accountName] = Form1.records[accountName]
                .Where(r => DateTime.TryParse(r.日期, out var d) && (DateTime.Now - d).TotalDays <= 14)
                .ToList();

            // 新增紀錄
            Form1.records[accountName].Add(new Form1.Record
            {
                日期 = date,
                星期 = weekday,
                餐別 = meal,
                時間 = DateTime.Now.ToString("HH:mm"),
                食物 = food,
                備註 = note
            });

            // 寫入 JSON 檔案
            string path = Path.Combine(Application.StartupPath, "records.json");
            string output = JsonSerializer.Serialize(Form1.records, new JsonSerializerOptions
            {
                WriteIndented = true,
                Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
            });
            File.WriteAllText(path, output, Encoding.UTF8);

            // 清空輸入欄位
            txtFoodName.Text = "";
            txtNote.Text = "";
            txtOther.Text = "";

            // 重新初始化日期選單，預設今日
            InitWeekSelector();
            for (int i = 0; i < comboBoxDaySelector.Items.Count; i++)
                if (comboBoxDaySelector.Items[i].ToString().Contains(date))
                {
                    comboBoxDaySelector.SelectedIndex = i;
                    break;
                }

            LoadRecordsJson();              // 重新載入資料
            UpdateListBoxByDate(accountName); // 更新列表
        }

        // 刪除選中紀錄按鈕
        private void btnDeleteRecord_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null)
            {
                MessageBox.Show("請先選擇一筆紀錄！");
                return;
            }

            if (listBox1.SelectedItem is Form1.Record selectedRecord && records.ContainsKey(currentAccount))
            {
                // 移除該筆紀錄（本地與全局皆刪除）
                records[currentAccount].RemoveAll(r =>
                    r.日期 == selectedRecord.日期 &&
                    r.餐別 == selectedRecord.餐別 &&
                    r.食物 == selectedRecord.食物 &&
                    r.備註 == selectedRecord.備註 &&
                    r.時間 == selectedRecord.時間);

                if (Form1.records.ContainsKey(currentAccount))
                    Form1.records[currentAccount].RemoveAll(r =>
                        r.日期 == selectedRecord.日期 &&
                        r.餐別 == selectedRecord.餐別 &&
                        r.食物 == selectedRecord.食物 &&
                        r.備註 == selectedRecord.備註 &&
                        r.時間 == selectedRecord.時間);

                // 更新 JSON
                string path = Path.Combine(Application.StartupPath, "records.json");
                string output = JsonSerializer.Serialize(Form1.records, new JsonSerializerOptions
                {
                    WriteIndented = true,
                    Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
                });
                File.WriteAllText(path, output, Encoding.UTF8);

                UpdateListBoxByDate(currentAccount); // 重新刷新列表
            }
            else
            {
                MessageBox.Show("請選擇有效紀錄！");
            }
        }

        // 當日期下拉選單變更，更新列表
        private void comboBoxDaySelector_SelectedIndexChanged(object sender, EventArgs e)
            => UpdateListBoxByDate(currentAccount);

        // 依 radio 狀態啟用或禁用自訂餐別輸入框
        private void radioOther_CheckedChanged(object sender, EventArgs e)
        {
            txtOther.Enabled = radioOther.Checked;
            if (!radioOther.Checked)
                txtOther.Text = "";
        }

        // 按鈕：打開統計視窗
        private void btnsStatistics_Click(object sender, EventArgs e)
        {
            StatisticsForm sf = new StatisticsForm(accountName);
            sf.Show();
        }

        // 取得星期英文DayOfWeek轉成中文數字
        private string GetChineseWeekDay(DayOfWeek day) => day switch
        {
            DayOfWeek.Monday => "一",
            DayOfWeek.Tuesday => "二",
            DayOfWeek.Wednesday => "三",
            DayOfWeek.Thursday => "四",
            DayOfWeek.Friday => "五",
            DayOfWeek.Saturday => "六",
            DayOfWeek.Sunday => "日",
            _ => ""
        };

        // 定義匯出 CSV 時使用的簡易飲食紀錄類別
        public class DietRecord
        {
            public DateTime Date { get; set; }
            public string Weekday { get; set; }
            public string Time { get; set; }
            public string MealType { get; set; }
            public string Content { get; set; }
        }

        // 匯出週報 CSV
        private void ExportWeeklyDetailedCsv(string filePath, List<DietRecord> records)
        {
            var sb = new StringBuilder();
            sb.AppendLine("日期,星期,時間,餐別,內容");

            DateTime? lastDate = null;
            foreach (var rec in records)
            {
                if (lastDate != null && rec.Date.Date != lastDate.Value.Date)
                    sb.AppendLine(); // 不同日期間空行分隔

                string dateStr = rec.Date.ToString("yyyy/MM/dd");
                sb.AppendLine($"{dateStr},{rec.Weekday},{rec.Time},{rec.MealType},{EscapeCsv(rec.Content)}");
                lastDate = rec.Date.Date;
            }

            File.WriteAllText(filePath, sb.ToString(), Encoding.UTF8);
        }

        // CSV 內含特殊字元時的處理
        private string EscapeCsv(string input)
        {
            if (string.IsNullOrEmpty(input)) return "";
            if (input.Contains(",") || input.Contains("\"") || input.Contains("\n"))
            {
                input = input.Replace("\"", "\"\"");
                return $"\"{input}\"";
            }
            return input;
        }

        // 匯出週報按鈕事件
        private void btnExportWeeklyReport_Click(object sender, EventArgs e)
        {
            DateTime today = DateTime.Today;
            int offset = (int)today.DayOfWeek == 0 ? 7 : (int)today.DayOfWeek;
            DateTime thisMonday = today.AddDays(-offset + 1);
            DateTime lastMonday = thisMonday.AddDays(-7);
            DateTime lastSunday = lastMonday.AddDays(6);
            DateTime thisSunday = thisMonday.AddDays(6);

            if (!Form1.records.ContainsKey(accountName))
            {
                MessageBox.Show("沒有該帳號的飲食紀錄。");
                return;
            }
            var allRecords = Form1.records[accountName];

            // 取得上週及本週的紀錄並排序
            var lastWeekRecords = allRecords
                .Where(r => DateTime.TryParse(r.日期, out DateTime d) && d >= lastMonday && d <= lastSunday)
                .Select(ToDietRecord)
                .OrderBy(r => r.Date).ThenBy(r => r.Time)
                .ToList();

            var thisWeekRecords = allRecords
                .Where(r => DateTime.TryParse(r.日期, out DateTime d) && d >= thisMonday && d <= thisSunday)
                .Select(ToDietRecord)
                .OrderBy(r => r.Date).ThenBy(r => r.Time)
                .ToList();

            string fileName = $"飲食週報_{accountName}_{lastMonday:yyyyMMdd}_{thisSunday:yyyyMMdd}.csv";
            string filePath = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.Desktop), fileName);

            var sb = new StringBuilder();
            sb.AppendLine("日期,星期,時間,餐別,內容");

            sb.AppendLine("# 上一週紀錄");
            sb.AppendLine(lastWeekRecords.Count > 0 ? BuildCsvSection(lastWeekRecords) : "無紀錄");
            sb.AppendLine();
            sb.AppendLine("# 本週紀錄");
            sb.AppendLine(thisWeekRecords.Count > 0 ? BuildCsvSection(thisWeekRecords) : "無紀錄");

            File.WriteAllText(filePath, sb.ToString(), Encoding.UTF8);

            // 開啟 CSV
            System.Diagnostics.Process.Start(new System.Diagnostics.ProcessStartInfo(filePath) { UseShellExecute = true });

            MessageBox.Show($"週報已匯出至桌面：{fileName}", "匯出成功");
        }

        // 將多筆紀錄格式化成 CSV 字串段落
        private string BuildCsvSection(List<DietRecord> records)
        {
            var sb = new StringBuilder();
            DateTime? lastDate = null;

            foreach (var rec in records)
            {
                if (lastDate != null && rec.Date.Date != lastDate.Value.Date)
                    sb.AppendLine();

                string dateStr = rec.Date.ToString("yyyy/MM/dd");
                sb.AppendLine($"{dateStr},{rec.Weekday},{rec.Time},{rec.MealType},{EscapeCsv(rec.Content)}");

                lastDate = rec.Date.Date;
            }
            return sb.ToString();
        }

        // 將 Form1.Record 轉成 DietRecord 方便匯出CSV用
        private DietRecord ToDietRecord(Form1.Record r)
        {
            DateTime.TryParse(r.日期, out DateTime date);
            return new DietRecord
            {
                Date = date,
                Weekday = $"({GetChineseWeekDay(date.DayOfWeek)})",
                Time = r.時間,
                MealType = r.餐別,
                Content = r.食物 + (string.IsNullOrEmpty(r.備註) ? "" : $" ({r.備註})")
            };
        }
    }
}
