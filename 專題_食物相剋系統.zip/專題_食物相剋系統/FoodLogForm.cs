﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.ComponentModel.Design.ObjectSelectorEditor;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static 專題_食物相剋系統.Form1;

namespace 專題_食物相剋系統
{
    public partial class FoodLogForm : Form
    {
        private FormResizer resizer = new FormResizer();
        // 傳入帳號名稱
        private string accountName;

        private Dictionary<string, List<Form1.Record>> records = new();
        private string currentAccount = "";
        public FoodLogForm(string account)
        {
            InitializeComponent();
            this.Load += FoodLogForm_Load;
            this.Resize += FoodLogForm_Resize;
            accountName = account;
            LoadRecordsJson();     // 載入紀錄資料
        }
        private void FoodLogForm_Load(object sender, EventArgs e)
        {
            resizer.CaptureOriginal(this);
            labelAccount.Text = "帳號： " + accountName;
            InitWeekSelector();    // 加上這行來建立下拉式選單
            currentAccount = accountName; // 同步帳號資訊

            // 自動選取今天日期（格式需包含 yyyy-MM-dd）
            string today = DateTime.Now.ToString("yyyy-MM-dd");
            for (int i = 0; i < comboBoxDaySelector.Items.Count; i++)
            {
                if (comboBoxDaySelector.Items[i].ToString().Contains(today))
                {
                    comboBoxDaySelector.SelectedIndex = i;
                    break;
                }
            }

            UpdateListBoxByDate(currentAccount); // 顯示選取日期的紀錄
        }
        private void FoodLogForm_Resize(object sender, EventArgs e)
        {
            resizer.ResizeAll(this);
        }
        private string GetSelectedMeal()
        {
            if (radioOther.Checked)
            {
                string other = txtOther.Text.Trim();
                return string.IsNullOrEmpty(other) ? null : other;
            }

            if (radioMorning.Checked) return "早餐";
            if (radioLunch.Checked) return "午餐";
            if (radioDinner.Checked) return "晚餐";
            if (radioSupper.Checked) return "宵夜";
            return null;
        }
        private void buttonBack2_Click(object sender, EventArgs e)
        {
            Form1 mainForm = Application.OpenForms["AccountForm"] as Form1;
            if (mainForm != null)
            {
                mainForm.Show(); // 顯示主畫面
            }
            this.Close();
        }
        private void InitWeekSelector()
        {
            comboBoxDaySelector.Items.Clear();

            DateTime today = DateTime.Today;
            DateTime thisMonday = today.AddDays(-(int)today.DayOfWeek + 1); // 本週一
            DateTime lastMonday = thisMonday.AddDays(-7);                   // 上週一

            List<(DateTime date, string label)> allDates = new();

            for (int i = 0; i < 7; i++)
            {
                DateTime dayThis = thisMonday.AddDays(i);
                DateTime dayLast = lastMonday.AddDays(i);

                allDates.Add((dayLast, $"上週 {dayLast:yyyy-MM-dd}（{dayLast:dddd}）"));
                allDates.Add((dayThis, $"本週 {dayThis:yyyy-MM-dd}（{dayThis:dddd}）"));
            }

            // 按日期排序
            allDates = allDates.OrderBy(d => d.date).ToList();

            // 加入 ComboBox
            foreach (var item in allDates)
            {
                comboBoxDaySelector.Items.Add(item.label);
            }

            comboBoxDaySelector.SelectedIndex = 0;
        }
        private void LoadRecordsJson()
        {
            string path = Path.Combine(Application.StartupPath, "records.json");

            if (File.Exists(path))
            {
                string json = File.ReadAllText(path, Encoding.UTF8);
                records = JsonSerializer.Deserialize<Dictionary<string, List<Form1.Record>>>(json);
            }
            else
            {
                records = new Dictionary<string, List<Form1.Record>>();
            }
        }
        private void UpdateListBoxByDate(string account)
        {
            if (!records.ContainsKey(account)) return;

            string selected = comboBoxDaySelector.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(selected)) return;

            // 擷取日期部分（例如 "2025-05-20"）
            int start = selected.IndexOf(' ') + 1;
            int end = selected.IndexOf('（');
            string dateStr = selected.Substring(start, end - start);

            listBox1.Items.Clear();

            var filtered = records[account]
                .Where(r => r.日期 == dateStr)
                .ToList();

            if (filtered.Count == 0)
            {
                listBox1.Items.Add("當天無紀錄");
            }
            else
            {
                foreach (var r in filtered)
                {
                    listBox1.Items.Add(r);
                }
            }
        }
        private void groupBox1_Paint(object sender, PaintEventArgs e)// 消除虛線
        {
            GroupBox box = (GroupBox)sender;
            e.Graphics.Clear(box.BackColor); // 清除預設樣式
            TextRenderer.DrawText(e.Graphics, box.Text, box.Font, new Point(8, 0), box.ForeColor); // 自行畫文字
        }

        private void groupBox2_Paint(object sender, PaintEventArgs e)// 消除虛線設計邊線
        {
            GroupBox box = (GroupBox)sender;
            e.Graphics.Clear(box.BackColor); // 清除預設樣式

            // 畫左邊和右邊實線
            using (Pen pen = new Pen(Color.Black, 1))
            {
                int topOffset = TextRenderer.MeasureText(box.Text, box.Font).Height / 2;

                // 左邊線
                e.Graphics.DrawLine(pen, 1, topOffset, 1, box.Height - 2);
                // 右邊線
                e.Graphics.DrawLine(pen, box.Width - 2, topOffset, box.Width - 2, box.Height - 2);
            }

            // 畫上標題文字
            TextRenderer.DrawText(
                e.Graphics,
                box.Text,
                box.Font,
                new Point(8, 0),
                box.ForeColor
            );
        }

        private void btnSaveRecord_Click(object sender, EventArgs e)
        {
            string food = txtFoodName.Text.Trim();    // 食物名稱
            string note = txtNote.Text.Trim();        // 備註
            string meal = GetSelectedMeal();          // 餐別


            if (string.IsNullOrEmpty(food) || string.IsNullOrEmpty(meal))
            {
                MessageBox.Show("請輸入食物並選擇餐別！");
                return;
            }

            string date = DateTime.Now.ToString("yyyy-MM-dd");
            string weekday = "一二三四五六日"[(int)DateTime.Now.DayOfWeek == 0 ? 6 : (int)DateTime.Now.DayOfWeek - 1].ToString();

            // 初始化帳號的紀錄區
            if (!Form1.records.ContainsKey(accountName))
                Form1.records[accountName] = new List<Record>();

            // 保留近 14 天資料
            DateTime today = DateTime.Today;
            int offset = today.DayOfWeek == DayOfWeek.Sunday ? 6 : (int)today.DayOfWeek - 1;
            DateTime thisMonday = today.AddDays(-offset);
            DateTime lastMonday = thisMonday.AddDays(-7);
            DateTime rangeStart = lastMonday;
            DateTime rangeEnd = thisMonday.AddDays(6);
            Form1.records[accountName] = Form1.records[accountName]
                .Where(r => DateTime.TryParse(r.日期, out var d) && (DateTime.Now - d).TotalDays <= 14)
                .ToList();

            // 加入新紀錄
            Form1.records[accountName].Add(new Record
            {
                日期 = date,
                星期 = weekday,
                餐別 = meal,
                時間 = DateTime.Now.ToString("HH:mm"),
                食物 = food,
                備註 = note
            });

            // 寫入 records.json
            string path = Path.Combine(Application.StartupPath, "records.json");
            string output = JsonSerializer.Serialize(Form1.records, new JsonSerializerOptions
            {
                WriteIndented = true,
                Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
            });
            File.WriteAllText(path, output, Encoding.UTF8);

            // 清空輸入欄位
            txtFoodName.Text = "";
            txtNote.Text = "";
            txtOther.Text = "";

            // 重新初始化 ComboBox 並選取今天日期
            InitWeekSelector();

            for (int i = 0; i < comboBoxDaySelector.Items.Count; i++)
            {
                if (comboBoxDaySelector.Items[i].ToString().Contains(date))
                {
                    comboBoxDaySelector.SelectedIndex = i;
                    break;
                }
            }
            LoadRecordsJson(); // 重新讀取最新 records.json        
            UpdateListBoxByDate(accountName);// 即時更新 ListBox 顯示
        }
        private void btnDeleteRecord_Click(object sender, EventArgs e)
        {
            if (listBox1.SelectedItem == null)
            {
                MessageBox.Show("請先選擇一筆紀錄！");
                return;
            }

            if (listBox1.SelectedItem is Form1.Record selectedRecord)
            {
                if (records.ContainsKey(currentAccount))
                {
                    // 刪除當前記憶體中的
                    records[currentAccount].RemoveAll(r =>
                        r.日期 == selectedRecord.日期 &&
                        r.餐別 == selectedRecord.餐別 &&
                        r.食物 == selectedRecord.食物 &&
                        r.備註 == selectedRecord.備註 &&
                        r.時間 == selectedRecord.時間
                    );

                    // 同時也刪掉 Form1 全域的記憶體資料
                    if (Form1.records.ContainsKey(currentAccount))
                    {
                        Form1.records[currentAccount].RemoveAll(r =>
                            r.日期 == selectedRecord.日期 &&
                            r.餐別 == selectedRecord.餐別 &&
                            r.食物 == selectedRecord.食物 &&
                            r.備註 == selectedRecord.備註 &&
                            r.時間 == selectedRecord.時間
                        );
                    }

                    // 寫回 JSON
                    string path = Path.Combine(Application.StartupPath, "records.json");
                    string output = JsonSerializer.Serialize(Form1.records, new JsonSerializerOptions
                    {
                        WriteIndented = true,
                        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
                    });
                    File.WriteAllText(path, output, Encoding.UTF8);

                    UpdateListBoxByDate(currentAccount); // 重新顯示
                }
            }
            else
            {
                MessageBox.Show("請選擇有效紀錄！");
            }
        }
        private void comboBoxDaySelector_SelectedIndexChanged(object sender, EventArgs e)
        {
            UpdateListBoxByDate(currentAccount);
        }

        private void radioOther_CheckedChanged(object sender, EventArgs e)
        {
            txtOther.Enabled = radioOther.Checked;
            if (!radioOther.Checked)
            {
                txtOther.Text = ""; // 清空輸入
            }
        }

        private void btnsStatistics_Click(object sender, EventArgs e)
        {
            // 開啟 StatisticsForm，傳入帳號名稱
            StatisticsForm sf = new StatisticsForm(accountName);
            sf.Show();
        }
    }
}
