using System.Text;
using System.Text.Json;

namespace 專題_食物相剋系統
{

    public partial class Form1 : Form
    {

        //彩虹顏色陣列
        int colorIndex = 0;
        Color[] rainbowColors = new Color[]
        {
            Color.Red, Color.Orange, Color.Khaki, Color.Green,
            Color.Blue, Color.Indigo, Color.Violet
        };
        string filePath = Path.Combine(Application.StartupPath, "accounts.json");// 登入資訊
        AccountStore store = new AccountStore();

        public static Dictionary<string, FoodData> foodInfo = new(); // 食物資訊
        string foodJsonPath = Path.Combine(Application.StartupPath, "food.json");

        public static Dictionary<string, List<Record>> records = new();// 紀錄資訊
        string recordPath = Path.Combine(Application.StartupPath, "records.json");
        public class AccountStore
        {
            public List<string> Accounts { get; set; } = new List<string>();
        }
        public class FoodData
        {
            public List<string> 優點 { get; set; }
            public List<string> 相剋 { get; set; }
            public string 後果 { get; set; }
            public string 解決辦法 { get; set; }
        }
        public class Record
        {
            public string 日期 { get; set; }
            public string 星期 { get; set; }
            public string 餐別 { get; set; }
            public string 食物 { get; set; }
            public string 備註 { get; set; }
            public string 時間 { get; set; }
            public override string ToString()//決定 Record 物件在 ListBox 中要顯示什麼文字
            {
                string notePart = string.IsNullOrEmpty(備註) ? "" : $"（{備註}）";
                return $"{餐別} {時間} {食物} {notePart}";
            }
        }
        public Form1()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            timerScroll.Tick += new EventHandler(timerScroll_Tick);
            timerColor.Tick += new EventHandler(timerColor_Tick);

        }
        private void SetTransparent(Control[] controls, Control parent)
        {
            foreach (Control ctrl in controls)
            {
                // 保留原來在螢幕上的位置
                Point screenPos = ctrl.PointToScreen(Point.Empty);

                // 換 Parent
                ctrl.Parent = parent;

                // 換完後轉換位置回新 Parent 內的區域座標
                ctrl.Location = parent.PointToClient(screenPos);

                // 設成透明
                ctrl.BackColor = Color.Transparent;
            }
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            label2.Visible = false;
            comboBox1.Visible = false;
            button2.Visible = false;
            button3.Visible = false;
            labelMarquee.Text = "歡迎使用食物相剋系統！常見食物過敏原：牛奶、蛋類、花生、堅果類、蕈菇類、大豆、小麥、海鮮、酒精、芒果、水果花粉類等。";
            labelMarquee.Font = new Font("標楷體", 18, FontStyle.Bold);
            labelMarquee.ForeColor = rainbowColors[colorIndex];
            labelMarquee.Left = this.Width;
            labelMarquee.Top = 50;
            timerScroll.Start();
            timerColor.Start();
            Control[] myControls = { label1, label2, label3, label4, labelMarquee, button1, button2, button3 };
            SetTransparent(myControls, pictureBox1);



            // 建立accounts.json檔案（如不存在）
            if (!File.Exists(filePath))
            {
                string initJson = JsonSerializer.Serialize(store, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(filePath, initJson);
            }
            // 載入帳號清單
            try
            {
                string json = File.ReadAllText(filePath, Encoding.UTF8);
                store = JsonSerializer.Deserialize<AccountStore>(json);
                comboBox1.Items.AddRange(store.Accounts.ToArray());
            }
            catch (Exception ex)
            {
                MessageBox.Show("讀取帳號資料失敗，原因：" + ex.Message, "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                // 如果發生錯誤，重新建立一個空的帳號清單
                store = new AccountStore();
            }
            //讀取food.json檔案
            if (File.Exists(foodJsonPath))
            {
                try
                {
                    string foodJson = File.ReadAllText(foodJsonPath, Encoding.UTF8);
                    foodInfo = JsonSerializer.Deserialize<Dictionary<string, FoodData>>(foodJson);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("讀取 food.json 失敗：" + ex.Message);
                }
            }
            //讀取records.json檔案
            if (File.Exists(recordPath))
            {
                try
                {
                    string json = File.ReadAllText(recordPath, Encoding.UTF8);
                    records = JsonSerializer.Deserialize<Dictionary<string, List<Record>>>(json);
                }
                catch (Exception ex)
                {
                    MessageBox.Show("讀取 records.json 失敗：" + ex.Message);
                }
            }
        }

        private void timerScroll_Tick(object sender, EventArgs e)
        {
            labelMarquee.Left -= 2;
            if (labelMarquee.Right <= 0)
            {
                // 讓 label 完整地從畫面右邊重新開始滑入
                labelMarquee.Left = this.Width;
            }
        }

        private void timerColor_Tick(object sender, EventArgs e)
        {
            // 每次改變顏色
            labelMarquee.ForeColor = rainbowColors[colorIndex];
            colorIndex = (colorIndex + 1) % rainbowColors.Length;
        }

        private void button1_Click(object sender, EventArgs e) //儲存帳號按鈕
        {
            string input = textBox1.Text.Trim();

            if (string.IsNullOrEmpty(input))
                return;

            // 判斷是否為 guest（不分大小寫）
            if (input.Equals("guest", StringComparison.OrdinalIgnoreCase))
            {
                textBox1.Text = "";
                GuestForm guestForm = new GuestForm();
                guestForm.Show();
                this.Hide();
                return;
            }
            // 判斷是否為 choose（不分大小寫）
            if (input.Equals("choose", StringComparison.OrdinalIgnoreCase))
            {
                label2.Visible = true;
                comboBox1.Visible = true;
                button2.Visible = true;
                button3.Visible = true;
                textBox1.Text = "";
                return;
            }
            // 一般帳號建立流程
            if (!store.Accounts.Contains(input))
            {
                label2.Visible = true;
                comboBox1.Visible = true;
                button2.Visible = true;
                button3.Visible = true;
                store.Accounts.Add(input);

                string jsonToSave = JsonSerializer.Serialize(store, new JsonSerializerOptions
                {
                    WriteIndented = true,
                    Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
                });

                File.WriteAllText(filePath, jsonToSave, Encoding.UTF8);

                comboBox1.Items.Add(input);
            }

            textBox1.Text = "";
        }
        private void button2_Click(object sender, EventArgs e) //確認帳號按鈕
        {
            // 取得選取的帳號名稱
            string selected = comboBox1.SelectedItem?.ToString();
            // 檢查是否選取了帳號
            if (string.IsNullOrEmpty(selected))
            {
                MessageBox.Show("請先選擇一個帳號", "提醒", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            // 開啟 AccountForm，傳入帳號名稱
            AccountForm form = new AccountForm(selected);
            form.Show();
            this.Hide();
        }
        private void button3_Click(object sender, EventArgs e) //刪除帳號按鈕
        {
            // 取得選取的帳號名稱
            string selectedAccount = comboBox1.SelectedItem?.ToString();
            // 檢查是否選取了帳號
            if (string.IsNullOrEmpty(selectedAccount))
            {
                MessageBox.Show("請先從下拉選單中選擇要刪除的帳號", "提醒", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            // 確認刪除
            if (store.Accounts.Contains(selectedAccount))
            {
                // 清除顯示與選取狀態
                comboBox1.SelectedIndex = -1;
                comboBox1.Text = "";

                // 從記憶體中移除
                store.Accounts.Remove(selectedAccount);

                // 更新 JSON 檔案
                string json = JsonSerializer.Serialize(store, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(filePath, json);

                //同時刪除該帳號對應的紀錄資料
                if (records.ContainsKey(selectedAccount))
                {
                    records.Remove(selectedAccount); // 從記憶體移除紀錄

                    //更新 records.json 檔案
                    string recordPath = Path.Combine(Application.StartupPath, "records.json");
                    string recordJson = JsonSerializer.Serialize(records, new JsonSerializerOptions
                    {
                        WriteIndented = true,
                        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
                    });
                    File.WriteAllText(recordPath, recordJson, Encoding.UTF8);
                }

                // 從下拉選單移除
                comboBox1.Items.Remove(selectedAccount);

            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            GuestForm guestForm = new GuestForm();
            guestForm.Show();
            this.Hide(); // 隱藏主畫面
        }

        
    }
}