using System.Text;
using System.Text.Json;

namespace 專題_食物相剋系統
{
    public partial class Form1 : Form
    {
        // 彩虹跑馬燈顏色陣列，循環變色
        int colorIndex = 0;
        Color[] rainbowColors = new Color[]
        {
            Color.Red, Color.Orange, Color.Khaki, Color.Green,
            Color.Blue, Color.Indigo, Color.Violet
        };

        // JSON 資料檔路徑
        string filePath = Path.Combine(Application.StartupPath, "accounts.json");  // 帳號
        string foodJsonPath = Path.Combine(Application.StartupPath, "food.json");  // 食物
        string recordPath = Path.Combine(Application.StartupPath, "records.json"); // 紀錄

        // 帳號清單物件
        AccountStore store = new AccountStore();

        // 靜態全局字典，方便跨類別存取
        public static Dictionary<string, FoodData> foodInfo = new();              // 食物資料
        public static Dictionary<string, List<Record>> records = new();            // 飲食紀錄

        // 用於 JSON 序列化的帳號列表
        public class AccountStore
        {
            public List<string> Accounts { get; set; } = new List<string>();
        }

        // 食物資訊資料結構
        public class FoodData
        {
            public List<string> 優點 { get; set; }
            public List<string> 相剋 { get; set; }
            public string 後果 { get; set; }
            public string 解決辦法 { get; set; }
        }

        // 飲食紀錄資料結構
        public class Record
        {
            public string 日期 { get; set; }
            public string 星期 { get; set; }
            public string 餐別 { get; set; }
            public string 食物 { get; set; }
            public string 備註 { get; set; }
            public string 時間 { get; set; }

            // 定義 ListBox 顯示格式
            public override string ToString()
            {
                string notePart = string.IsNullOrEmpty(備註) ? "" : $"（{備註}）";
                return $"{餐別} {時間} {食物} {notePart}";
            }
        }

        // 建構子：初始化元件與跑馬燈計時器事件
        public Form1()
        {
            InitializeComponent();
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            timerScroll.Tick += timerScroll_Tick;
            timerColor.Tick += timerColor_Tick;
        }

        // 將控制項陣列設為透明背景，並重新定位到指定父容器
        private void SetTransparent(Control[] controls, Control parent)
        {
            foreach (Control ctrl in controls)
            {
                Point screenPos = ctrl.PointToScreen(Point.Empty);
                ctrl.Parent = parent;
                ctrl.Location = parent.PointToClient(screenPos);
                ctrl.BackColor = Color.Transparent;
            }
        }

        // 載入事件：初始化 UI 與載入 JSON 資料
        private void Form1_Load(object sender, EventArgs e)
        {
            // 隱藏部分控制項
            label2.Visible = false;
            comboBox1.Visible = false;
            btnLogin.Visible = false;
            btnDelete.Visible = false;

            // 設定跑馬燈文字與字型、位置
            labelMarquee.Text = "歡迎使用食物相剋系統！常見食物過敏原：牛奶、蛋類、花生、堅果類、蕈菇類、大豆、小麥、海鮮、酒精、芒果、水果花粉類等。";
            labelMarquee.Font = new Font("標楷體", 18, FontStyle.Bold);
            labelMarquee.ForeColor = rainbowColors[colorIndex];
            labelMarquee.Left = this.Width;
            labelMarquee.Top = 50;

            // 啟動跑馬燈計時器
            timerScroll.Start();
            timerColor.Start();

            // 設定多個控制項透明背景，並移動到 pictureBox1
            Control[] controls = { label1, label2, label3, label4, labelMarquee, btnConfirm, btnLogin, btnDelete };
            SetTransparent(controls, pictureBox1);

            // 若 accounts.json 不存在，建立空白帳號檔案
            if (!File.Exists(filePath))
            {
                string initJson = JsonSerializer.Serialize(store, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(filePath, initJson);
            }

            // 載入帳號資料，填充下拉選單
            try
            {
                string json = File.ReadAllText(filePath, Encoding.UTF8);
                store = JsonSerializer.Deserialize<AccountStore>(json);
                comboBox1.Items.AddRange(store.Accounts.ToArray());
            }
            catch (Exception ex)
            {
                MessageBox.Show($"讀取帳號資料失敗，原因：{ex.Message}", "錯誤", MessageBoxButtons.OK, MessageBoxIcon.Error);
                store = new AccountStore();
            }

            // 載入食物資料
            if (File.Exists(foodJsonPath))
            {
                try
                {
                    string foodJson = File.ReadAllText(foodJsonPath, Encoding.UTF8);
                    foodInfo = JsonSerializer.Deserialize<Dictionary<string, FoodData>>(foodJson);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"讀取 food.json 失敗：{ex.Message}");
                }
            }

            // 載入飲食紀錄資料
            if (File.Exists(recordPath))
            {
                try
                {
                    string json = File.ReadAllText(recordPath, Encoding.UTF8);
                    records = JsonSerializer.Deserialize<Dictionary<string, List<Record>>>(json);
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"讀取 records.json 失敗：{ex.Message}");
                }
            }
        }

        // 跑馬燈文字左移，超出左邊邊界時從右側重新開始
        private void timerScroll_Tick(object sender, EventArgs e)
        {
            labelMarquee.Left -= 2;
            if (labelMarquee.Right <= 0)
                labelMarquee.Left = this.Width;
        }

        // 跑馬燈文字顏色循環變換
        private void timerColor_Tick(object sender, EventArgs e)
        {
            labelMarquee.ForeColor = rainbowColors[colorIndex];
            colorIndex = (colorIndex + 1) % rainbowColors.Length;
        }

        // 儲存帳號按鈕事件
        private void btnConfirm_Click(object sender, EventArgs e)
        {
            string input = textBox1.Text.Trim();
            if (string.IsNullOrEmpty(input))
                return;

            // 防止重複帳號
            if (store.Accounts.Contains(input))
            {
                MessageBox.Show("已有同名帳號名稱", "帳號重複", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // 特殊帳號 guest，啟動 GuestForm
            if (input.Equals("guest", StringComparison.OrdinalIgnoreCase))
            {
                textBox1.Text = "";
                new GuestForm().Show();
                this.Hide();
                return;
            }

            // 特殊帳號 choose，顯示帳號選單
            if (input.Equals("choose", StringComparison.OrdinalIgnoreCase))
            {
                label2.Visible = true;
                comboBox1.Visible = true;
                btnLogin.Visible = true;
                btnDelete.Visible = true;
                textBox1.Text = "";
                return;
            }

            // 新增一般帳號
            if (!store.Accounts.Contains(input))
            {
                label2.Visible = true;
                comboBox1.Visible = true;
                btnLogin.Visible = true;
                btnDelete.Visible = true;
                store.Accounts.Add(input);

                string jsonToSave = JsonSerializer.Serialize(store, new JsonSerializerOptions
                {
                    WriteIndented = true,
                    Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
                });
                File.WriteAllText(filePath, jsonToSave, Encoding.UTF8);
                comboBox1.Items.Add(input);
            }

            textBox1.Text = "";
        }

        // 確認帳號按鈕事件，開啟 AccountForm
        private void btnLogin_Click(object sender, EventArgs e)
        {
            string selected = comboBox1.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(selected))
            {
                MessageBox.Show("請先選擇一個帳號", "提醒", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            new AccountForm(selected).Show();
            this.Hide();
        }

        // 刪除帳號事件，刪除帳號及相關飲食紀錄
        private void btnDelete_Click(object sender, EventArgs e)
        {
            string selectedAccount = comboBox1.SelectedItem?.ToString();
            if (string.IsNullOrEmpty(selectedAccount))
            {
                MessageBox.Show("請先從下拉選單中選擇要刪除的帳號", "提醒", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            if (store.Accounts.Contains(selectedAccount))
            {
                comboBox1.SelectedIndex = -1;
                comboBox1.Text = "";

                // 移除帳號
                store.Accounts.Remove(selectedAccount);

                // 更新 accounts.json
                string json = JsonSerializer.Serialize(store, new JsonSerializerOptions { WriteIndented = true });
                File.WriteAllText(filePath, json);

                // 移除帳號相關的飲食紀錄
                if (records.ContainsKey(selectedAccount))
                {
                    records.Remove(selectedAccount);
                    string recordJson = JsonSerializer.Serialize(records, new JsonSerializerOptions
                    {
                        WriteIndented = true,
                        Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
                    });
                    File.WriteAllText(recordPath, recordJson, Encoding.UTF8);
                }

                // 更新下拉清單
                comboBox1.Items.Remove(selectedAccount);
            }
        }
    }
}
