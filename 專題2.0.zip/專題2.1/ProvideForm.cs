﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.Json;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 專題2._0
{
    public partial class ProvideForm : Form
    {
        public ProvideForm()
        {
            InitializeComponent();
        }

        private void buttonSave_Click(object sender, EventArgs e)
        {
            //讀取輸入的資料
            string foodName = txtFood.Text.Trim();
            string advantages = txtAdvantage.Text.Trim();
            string conflicts = txtConflict.Text.Trim();
            string consequence = txtConsequence.Text.Trim();
            string solution = txtSolution.Text.Trim();

            //檢查是否有空值
            if (string.IsNullOrEmpty(foodName))
            {
                MessageBox.Show("請輸入食物名稱");
                return;
            }

            //組成要寫入的資料物件
            var newData = new
            {
                優點 = advantages.Split(',').Select(a => a.Trim()).ToList(),
                相剋 = conflicts.Split(',').Select(a => a.Trim()).ToList(),
                後果 = consequence,
                解決辦法 = solution
            };

            //設定JSON 路徑
            string path = Path.Combine(Application.StartupPath, "food.json");

            //讀取現有資料（如果檔案存在）
            Dictionary<string, Form1.FoodData> foodDict = new();
            if (File.Exists(path))
            {
                string json = File.ReadAllText(path, Encoding.UTF8);
                foodDict = JsonSerializer.Deserialize<Dictionary<string, Form1.FoodData>>(json);
            }

            //更新或新增資料
            foodDict[foodName] = new Form1.FoodData
            {
                優點 = newData.優點,
                相剋 = newData.相剋,
                後果 = newData.後果,
                解決辦法 = newData.解決辦法
            };

            //寫入JSON
            string jsonOutput = JsonSerializer.Serialize(foodDict, new JsonSerializerOptions
            {
                WriteIndented = true,
                Encoder = System.Text.Encodings.Web.JavaScriptEncoder.UnsafeRelaxedJsonEscaping
            });

            File.WriteAllText(path, jsonOutput, Encoding.UTF8);

            // 寫完檔案後重新讀入到 Form1的全域 foodInfo
            string Formjson = File.ReadAllText(Path.Combine(Application.StartupPath, "food.json"), Encoding.UTF8);
            Form1.foodInfo = JsonSerializer.Deserialize<Dictionary<string, Form1.FoodData>>(Formjson);

            //清空欄位
            txtFood.Text = txtAdvantage.Text = txtConflict.Text = txtConsequence.Text = txtSolution.Text = "";
        }

        private void buttonBack_Click(object sender, EventArgs e)
        {
            Form1 mainForm = Application.OpenForms["AccountForm"] as Form1;
            if (mainForm != null)
            {
                mainForm.Show(); // 顯示主畫面
            }
            this.Close();
        }
    }
}
