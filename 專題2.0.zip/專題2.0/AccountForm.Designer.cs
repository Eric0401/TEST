﻿namespace 專題2._0
{
    partial class AccountForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            labelAccount = new Label();
            panel1 = new Panel();
            btnPotato = new Button();
            btnCucumber = new Button();
            btnTomato = new Button();
            btnGreenOnion = new Button();
            btnHoney = new Button();
            btnGarlic = new Button();
            btnSpinach = new Button();
            btnSoybean = new Button();
            btnPorkBlood = new Button();
            btnKelp = new Button();
            btnOrange = new Button();
            btnMilk = new Button();
            btnBanana = new Button();
            btnCarrot = new Button();
            btnApple = new Button();
            textBox1 = new TextBox();
            buttonSearch = new Button();
            buttonProvide = new Button();
            buttonSignout = new Button();
            tableLayoutPanel1 = new TableLayoutPanel();
            buttonEat = new Button();
            groupBox1 = new GroupBox();
            txtList = new TextBox();
            panel1.SuspendLayout();
            tableLayoutPanel1.SuspendLayout();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // labelAccount
            // 
            labelAccount.AutoSize = true;
            labelAccount.BackColor = Color.Cornsilk;
            labelAccount.Font = new Font("Microsoft JhengHei UI", 20.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            labelAccount.Location = new Point(89, 62);
            labelAccount.Name = "labelAccount";
            labelAccount.Size = new Size(103, 35);
            labelAccount.TabIndex = 0;
            labelAccount.Text = "帳號： ";
            // 
            // panel1
            // 
            panel1.AutoScroll = true;
            panel1.BackColor = Color.White;
            panel1.Controls.Add(btnPotato);
            panel1.Controls.Add(btnCucumber);
            panel1.Controls.Add(btnTomato);
            panel1.Controls.Add(btnGreenOnion);
            panel1.Controls.Add(btnHoney);
            panel1.Controls.Add(btnGarlic);
            panel1.Controls.Add(btnSpinach);
            panel1.Controls.Add(btnSoybean);
            panel1.Controls.Add(btnPorkBlood);
            panel1.Controls.Add(btnKelp);
            panel1.Controls.Add(btnOrange);
            panel1.Controls.Add(btnMilk);
            panel1.Controls.Add(btnBanana);
            panel1.Controls.Add(btnCarrot);
            panel1.Controls.Add(btnApple);
            panel1.Location = new Point(95, 162);
            panel1.Name = "panel1";
            panel1.Size = new Size(370, 316);
            panel1.TabIndex = 1;
            // 
            // btnPotato
            // 
            btnPotato.Font = new Font("Microsoft JhengHei UI", 12F);
            btnPotato.Location = new Point(261, 445);
            btnPotato.Name = "btnPotato";
            btnPotato.Size = new Size(75, 75);
            btnPotato.TabIndex = 14;
            btnPotato.Text = "馬鈴薯";
            btnPotato.UseVisualStyleBackColor = true;
            // 
            // btnCucumber
            // 
            btnCucumber.Font = new Font("Microsoft JhengHei UI", 12F);
            btnCucumber.Location = new Point(142, 445);
            btnCucumber.Name = "btnCucumber";
            btnCucumber.Size = new Size(75, 75);
            btnCucumber.TabIndex = 13;
            btnCucumber.Text = "黃瓜";
            btnCucumber.UseVisualStyleBackColor = true;
            // 
            // btnTomato
            // 
            btnTomato.Font = new Font("Microsoft JhengHei UI", 12F);
            btnTomato.Location = new Point(22, 445);
            btnTomato.Name = "btnTomato";
            btnTomato.Size = new Size(75, 75);
            btnTomato.TabIndex = 12;
            btnTomato.Text = "蕃茄";
            btnTomato.UseVisualStyleBackColor = true;
            // 
            // btnGreenOnion
            // 
            btnGreenOnion.Font = new Font("Microsoft JhengHei UI", 12F);
            btnGreenOnion.Location = new Point(261, 339);
            btnGreenOnion.Name = "btnGreenOnion";
            btnGreenOnion.Size = new Size(75, 75);
            btnGreenOnion.TabIndex = 11;
            btnGreenOnion.Text = "大蔥";
            btnGreenOnion.UseVisualStyleBackColor = true;
            // 
            // btnHoney
            // 
            btnHoney.Font = new Font("Microsoft JhengHei UI", 12F);
            btnHoney.Location = new Point(142, 339);
            btnHoney.Name = "btnHoney";
            btnHoney.Size = new Size(75, 75);
            btnHoney.TabIndex = 10;
            btnHoney.Text = "蜂蜜";
            btnHoney.UseVisualStyleBackColor = true;
            // 
            // btnGarlic
            // 
            btnGarlic.Font = new Font("Microsoft JhengHei UI", 12F);
            btnGarlic.Location = new Point(22, 339);
            btnGarlic.Name = "btnGarlic";
            btnGarlic.Size = new Size(75, 75);
            btnGarlic.TabIndex = 9;
            btnGarlic.Text = "大蒜";
            btnGarlic.UseVisualStyleBackColor = true;
            // 
            // btnSpinach
            // 
            btnSpinach.Font = new Font("Microsoft JhengHei UI", 12F);
            btnSpinach.Location = new Point(261, 238);
            btnSpinach.Name = "btnSpinach";
            btnSpinach.Size = new Size(75, 75);
            btnSpinach.TabIndex = 8;
            btnSpinach.Text = "菠菜";
            btnSpinach.UseVisualStyleBackColor = true;
            // 
            // btnSoybean
            // 
            btnSoybean.Font = new Font("Microsoft JhengHei UI", 12F);
            btnSoybean.Location = new Point(143, 238);
            btnSoybean.Name = "btnSoybean";
            btnSoybean.Size = new Size(75, 75);
            btnSoybean.TabIndex = 7;
            btnSoybean.Text = "黃豆";
            btnSoybean.UseVisualStyleBackColor = true;
            // 
            // btnPorkBlood
            // 
            btnPorkBlood.Font = new Font("Microsoft JhengHei UI", 12F);
            btnPorkBlood.Location = new Point(22, 238);
            btnPorkBlood.Name = "btnPorkBlood";
            btnPorkBlood.Size = new Size(75, 75);
            btnPorkBlood.TabIndex = 6;
            btnPorkBlood.Text = "豬血";
            btnPorkBlood.UseVisualStyleBackColor = true;
            // 
            // btnKelp
            // 
            btnKelp.Font = new Font("Microsoft JhengHei UI", 12F);
            btnKelp.Location = new Point(261, 135);
            btnKelp.Name = "btnKelp";
            btnKelp.Size = new Size(75, 75);
            btnKelp.TabIndex = 5;
            btnKelp.Text = "海帶";
            btnKelp.UseVisualStyleBackColor = true;
            // 
            // btnOrange
            // 
            btnOrange.Font = new Font("Microsoft JhengHei UI", 12F);
            btnOrange.Location = new Point(143, 135);
            btnOrange.Name = "btnOrange";
            btnOrange.Size = new Size(75, 75);
            btnOrange.TabIndex = 4;
            btnOrange.Text = "橘子";
            btnOrange.UseVisualStyleBackColor = true;
            // 
            // btnMilk
            // 
            btnMilk.Font = new Font("Microsoft JhengHei UI", 12F);
            btnMilk.Location = new Point(22, 135);
            btnMilk.Name = "btnMilk";
            btnMilk.Size = new Size(75, 75);
            btnMilk.TabIndex = 3;
            btnMilk.Text = "牛奶";
            btnMilk.UseVisualStyleBackColor = true;
            // 
            // btnBanana
            // 
            btnBanana.Font = new Font("Microsoft JhengHei UI", 12F);
            btnBanana.Location = new Point(261, 35);
            btnBanana.Name = "btnBanana";
            btnBanana.Size = new Size(75, 75);
            btnBanana.TabIndex = 2;
            btnBanana.Text = "香蕉";
            btnBanana.UseVisualStyleBackColor = true;
            // 
            // btnCarrot
            // 
            btnCarrot.Font = new Font("Microsoft JhengHei UI", 12F);
            btnCarrot.Location = new Point(143, 35);
            btnCarrot.Name = "btnCarrot";
            btnCarrot.Size = new Size(75, 75);
            btnCarrot.TabIndex = 1;
            btnCarrot.Text = "胡蘿蔔";
            btnCarrot.UseVisualStyleBackColor = true;
            // 
            // btnApple
            // 
            btnApple.Font = new Font("Microsoft JhengHei UI", 12F);
            btnApple.Location = new Point(22, 35);
            btnApple.Name = "btnApple";
            btnApple.Size = new Size(75, 75);
            btnApple.TabIndex = 0;
            btnApple.Text = "蘋果";
            btnApple.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Microsoft JhengHei UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 136);
            textBox1.Location = new Point(518, 118);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(258, 38);
            textBox1.TabIndex = 3;
            textBox1.KeyDown += textBox1_KeyDown;
            // 
            // buttonSearch
            // 
            buttonSearch.BackColor = Color.White;
            buttonSearch.Font = new Font("Microsoft JhengHei UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 136);
            buttonSearch.Location = new Point(721, 71);
            buttonSearch.Name = "buttonSearch";
            buttonSearch.Size = new Size(94, 39);
            buttonSearch.TabIndex = 4;
            buttonSearch.Text = "查詢";
            buttonSearch.UseVisualStyleBackColor = false;
            buttonSearch.Click += buttonSearch_Click;
            // 
            // buttonProvide
            // 
            buttonProvide.Anchor = AnchorStyles.None;
            buttonProvide.Font = new Font("Microsoft JhengHei UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 136);
            buttonProvide.Location = new Point(6, 0);
            buttonProvide.Margin = new Padding(0);
            buttonProvide.Name = "buttonProvide";
            buttonProvide.Size = new Size(172, 39);
            buttonProvide.TabIndex = 5;
            buttonProvide.Text = "資   料   更   新";
            buttonProvide.UseVisualStyleBackColor = true;
            buttonProvide.Click += buttonProvide_Click;
            // 
            // buttonSignout
            // 
            buttonSignout.BackColor = Color.White;
            buttonSignout.Font = new Font("Microsoft JhengHei UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 136);
            buttonSignout.Location = new Point(721, 22);
            buttonSignout.Name = "buttonSignout";
            buttonSignout.Size = new Size(94, 39);
            buttonSignout.TabIndex = 6;
            buttonSignout.Text = "登出";
            buttonSignout.UseVisualStyleBackColor = false;
            buttonSignout.Click += btnsignout_Click;
            // 
            // tableLayoutPanel1
            // 
            tableLayoutPanel1.BackColor = Color.Cornsilk;
            tableLayoutPanel1.ColumnCount = 2;
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Controls.Add(buttonEat, 1, 0);
            tableLayoutPanel1.Controls.Add(buttonProvide, 0, 0);
            tableLayoutPanel1.Location = new Point(95, 117);
            tableLayoutPanel1.Name = "tableLayoutPanel1";
            tableLayoutPanel1.RowCount = 1;
            tableLayoutPanel1.RowStyles.Add(new RowStyle(SizeType.Percent, 50F));
            tableLayoutPanel1.Size = new Size(370, 39);
            tableLayoutPanel1.TabIndex = 7;
            // 
            // buttonEat
            // 
            buttonEat.Anchor = AnchorStyles.None;
            buttonEat.Font = new Font("Microsoft JhengHei UI", 18F, FontStyle.Regular, GraphicsUnit.Point, 136);
            buttonEat.Location = new Point(191, 0);
            buttonEat.Margin = new Padding(0);
            buttonEat.Name = "buttonEat";
            buttonEat.Size = new Size(172, 39);
            buttonEat.TabIndex = 6;
            buttonEat.Text = "飲   食   紀   錄";
            buttonEat.UseVisualStyleBackColor = true;
            buttonEat.Click += buttonEat_Click;
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.Cornsilk;
            groupBox1.Controls.Add(txtList);
            groupBox1.Controls.Add(buttonSignout);
            groupBox1.Controls.Add(buttonSearch);
            groupBox1.Location = new Point(73, 46);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(835, 450);
            groupBox1.TabIndex = 8;
            groupBox1.TabStop = false;
            groupBox1.Paint += groupBox1_Paint;
            // 
            // txtList
            // 
            txtList.Font = new Font("Microsoft JhengHei UI", 15.75F, FontStyle.Regular, GraphicsUnit.Point, 136);
            txtList.Location = new Point(445, 116);
            txtList.Multiline = true;
            txtList.Name = "txtList";
            txtList.ReadOnly = true;
            txtList.ScrollBars = ScrollBars.Vertical;
            txtList.Size = new Size(370, 313);
            txtList.TabIndex = 7;
            // 
            // AccountForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.FromArgb(192, 255, 192);
            ClientSize = new Size(984, 561);
            Controls.Add(tableLayoutPanel1);
            Controls.Add(textBox1);
            Controls.Add(panel1);
            Controls.Add(labelAccount);
            Controls.Add(groupBox1);
            Name = "AccountForm";
            Text = "相剋查詢";
            Load += AccountForm_Load;
            panel1.ResumeLayout(false);
            tableLayoutPanel1.ResumeLayout(false);
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        protected Label labelAccount;
        protected Panel panel1;
        private Button btnApple;
        private Button btnPorkBlood;
        private Button btnKelp;
        private Button btnOrange;
        private Button btnMilk;
        private Button btnBanana;
        private Button btnCarrot;
        private Button btnPotato;
        private Button btnCucumber;
        private Button btnTomato;
        private Button btnGreenOnion;
        private Button btnHoney;
        private Button btnGarlic;
        private Button btnSpinach;
        private Button btnSoybean;
        protected TextBox textBox1;
        protected Button buttonSearch;
        protected Button buttonProvide;
        protected Button buttonSignout;
        private TableLayoutPanel tableLayoutPanel1;
        protected Button buttonEat;
        private GroupBox groupBox1;
        private TextBox txtList;
    }
}