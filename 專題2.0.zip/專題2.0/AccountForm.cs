﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 專題2._0
{
    public partial class AccountForm : Form
    {
        private string accountName;
        public AccountForm(string account)
        {
            InitializeComponent();
            accountName = account;
        }

        private void AccountForm_Load(object sender, EventArgs e)
        {
            labelAccount.Text = "帳號： " + accountName;
        }
    }
}
