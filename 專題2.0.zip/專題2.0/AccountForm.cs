﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 專題2._0
{
    public partial class AccountForm : Form
    {
        // 傳入帳號名稱
        private string accountName;
        public AccountForm(string account)
        {
            InitializeComponent();
            accountName = account;
        }
        protected AccountForm() : this("訪客")
        {}

        protected virtual void AccountForm_Load(object sender, EventArgs e)
        {
            labelAccount.Text = "帳號： " + accountName;

            // 自動綁定所有 btn 開頭的按鈕點擊事件到同一個方法
            foreach (Control ctrl in panel1.Controls)
            {
                if (ctrl is Button btn && btn.Name.StartsWith("btn"))
                {
                    btn.Click += FoodButton_Click;
                }
            }
        }

        protected virtual void btnsignout_Click(object sender, EventArgs e) //登出回到主畫面
        {
            Form1 mainForm = Application.OpenForms["Form1"] as Form1;
            if (mainForm != null)
            {
                mainForm.Show(); // 顯示主畫面
            }
            this.Close();
        }
        protected virtual void FoodButton_Click(object sender, EventArgs e)
        {

            // 取得是哪個按鈕被點擊
            Button btn = sender as Button;
            if (btn == null) return;

            // 用按鈕的 Text 當作食物名稱
            string foodName = btn.Text;

            // 清空 ListBox，準備顯示新的資料
            txtList.Clear();

            // 從 Form1 的 foodInfo 中查找食物資料
            if (Form1.foodInfo.ContainsKey(foodName))
            {
                var data = Form1.foodInfo[foodName];
                txtList.AppendText($"食物：{foodName}\r\n");
                txtList.AppendText($"優點：{string.Join("、", data.優點)}\r\n");
                txtList.AppendText($"相剋：{string.Join("、", data.相剋)}\r\n");
                txtList.AppendText($"後果：{data.後果}\r\n");
                txtList.AppendText($"解決辦法：{data.解決辦法}\r\n");
            }
            else
            {
                txtList.AppendText("查無資料");
            }
        }

        protected virtual void buttonSearch_Click(object sender, EventArgs e)
        {
            string keyword = textBox1.Text.Trim(); // 取得使用者輸入的文字
            txtList.Clear(); // 清除原本顯示

            if (string.IsNullOrEmpty(keyword))
            {
                txtList.AppendText("請輸入食物名稱");
                return;
            }

            if (Form1.foodInfo.ContainsKey(keyword))
            {
                var data = Form1.foodInfo[keyword];
                txtList.AppendText($"食物: {keyword}");
                txtList.AppendText($"優點: {string.Join(", ", data.優點)}");
                txtList.AppendText($"相剋: {string.Join(", ", data.相剋)}");
                txtList.AppendText($"後果: {data.後果}");
                txtList.AppendText($"解決辦法: {data.解決辦法}");
            }
            else
            {
                txtList.AppendText("查無此食物，請自行新增");
            }
        }

        protected virtual void textBox1_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                buttonSearch.PerformClick();   // 模擬點擊查詢按鈕
                e.SuppressKeyPress = true;     // 不讓系統發出「叮」聲
            }
        }

        protected virtual void buttonProvide_Click(object sender, EventArgs e)
        {
            ProvideForm pf = new ProvideForm();
            pf.Show();         // 開啟新的資料填寫表單
        }

        protected virtual void buttonEat_Click(object sender, EventArgs e)
        {
            FoodLogForm flf = new FoodLogForm(accountName);
            flf.Show();
        }

        protected virtual void groupBox1_Paint(object sender, PaintEventArgs e)// 消除虛線
        {
            GroupBox box = (GroupBox)sender;
            e.Graphics.Clear(box.BackColor); // 清除預設底色

            using (Pen borderPen = new Pen(Color.Black, 1))
            {
                e.Graphics.DrawRectangle(borderPen, 0, 0, box.Width - 1, box.Height - 1);
            }
        }
    }
}
