﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace 專題2._0
{
    public partial class GuestForm : AccountForm
    {
        public GuestForm() : base("訪客")
        {
            InitializeComponent();

            // 改為載入 GuestForm_Load 而不是 AccountForm_Load
            this.Load += GuestForm_Load;
        }

        // 改為獨立的 GuestForm 載入事件方法
        private void GuestForm_Load(object sender, EventArgs e)
        {
            // 呼叫 AccountForm 的原始初始化邏輯
            base.AccountForm_Load(sender, e);

            // 限制訪客不能進行新增/記錄
            buttonEat.Enabled = false;
            buttonProvide.Enabled = false;
            labelAccount.Text = "身份：訪客（僅能查詢）";
        }
    }
}
