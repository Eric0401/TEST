﻿namespace 專題2._0
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            label1 = new Label();
            button1 = new Button();
            textBox1 = new TextBox();
            comboBox1 = new ComboBox();
            label2 = new Label();
            label4 = new Label();
            groupBox1 = new GroupBox();
            button3 = new Button();
            button2 = new Button();
            label3 = new Label();
            labelMarquee = new Label();
            timerScroll = new System.Windows.Forms.Timer(components);
            timer1 = new System.Windows.Forms.Timer(components);
            timerColor = new System.Windows.Forms.Timer(components);
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.FromArgb(192, 255, 192);
            label1.Font = new Font("Microsoft JhengHei UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label1.Location = new Point(288, 234);
            label1.Name = "label1";
            label1.Size = new Size(105, 24);
            label1.TabIndex = 0;
            label1.Text = "建立帳號：";
            // 
            // button1
            // 
            button1.BackColor = Color.White;
            button1.Font = new Font("Microsoft JhengHei UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            button1.Location = new Point(582, 231);
            button1.Name = "button1";
            button1.Size = new Size(77, 32);
            button1.TabIndex = 1;
            button1.Text = "確認";
            button1.UseVisualStyleBackColor = false;
            button1.Click += button1_Click;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Microsoft JhengHei UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            textBox1.Location = new Point(399, 231);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(166, 32);
            textBox1.TabIndex = 2;
            // 
            // comboBox1
            // 
            comboBox1.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBox1.Font = new Font("Microsoft JhengHei UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            comboBox1.FormattingEnabled = true;
            comboBox1.Location = new Point(399, 334);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(166, 32);
            comboBox1.TabIndex = 4;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.FromArgb(192, 255, 192);
            label2.Font = new Font("Microsoft JhengHei UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            label2.Location = new Point(288, 337);
            label2.Name = "label2";
            label2.Size = new Size(105, 24);
            label2.TabIndex = 5;
            label2.Text = "切換帳號：";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BackColor = Color.FromArgb(192, 255, 192);
            label4.Font = new Font("Microsoft JhengHei UI", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 136);
            label4.Location = new Point(225, 283);
            label4.Name = "label4";
            label4.Size = new Size(516, 26);
            label4.TabIndex = 6;
            label4.Text = "--------------------------------------------------------";
            // 
            // groupBox1
            // 
            groupBox1.BackColor = Color.FromArgb(192, 255, 192);
            groupBox1.Controls.Add(button3);
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(label3);
            groupBox1.Font = new Font("Microsoft JhengHei UI", 24F, FontStyle.Regular, GraphicsUnit.Point, 136);
            groupBox1.Location = new Point(201, 98);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(570, 384);
            groupBox1.TabIndex = 7;
            groupBox1.TabStop = false;
            groupBox1.Paint += groupBox1_Paint;
            // 
            // button3
            // 
            button3.BackColor = Color.White;
            button3.Font = new Font("Microsoft JhengHei UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            button3.Location = new Point(464, 235);
            button3.Name = "button3";
            button3.Size = new Size(77, 32);
            button3.TabIndex = 10;
            button3.Text = "刪除";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click;
            // 
            // button2
            // 
            button2.BackColor = Color.White;
            button2.Font = new Font("Microsoft JhengHei UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            button2.Location = new Point(381, 235);
            button2.Name = "button2";
            button2.Size = new Size(77, 32);
            button2.TabIndex = 9;
            button2.Text = "登入";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Microsoft JhengHei UI", 24F, FontStyle.Bold, GraphicsUnit.Point, 136);
            label3.Location = new Point(176, 44);
            label3.Name = "label3";
            label3.Size = new Size(210, 41);
            label3.TabIndex = 8;
            label3.Text = "食物相剋系統";
            // 
            // labelMarquee
            // 
            labelMarquee.AutoSize = true;
            labelMarquee.Font = new Font("Microsoft JhengHei UI", 14.25F, FontStyle.Regular, GraphicsUnit.Point, 136);
            labelMarquee.Location = new Point(887, 36);
            labelMarquee.Name = "labelMarquee";
            labelMarquee.Size = new Size(0, 24);
            labelMarquee.TabIndex = 8;
            // 
            // timerScroll
            // 
            timerScroll.Enabled = true;
            timerScroll.Interval = 50;
            timerScroll.Tick += timerScroll_Tick;
            // 
            // timer1
            // 
            timer1.Enabled = true;
            timer1.Interval = 50;
            // 
            // timerColor
            // 
            timerColor.Enabled = true;
            timerColor.Interval = 200;
            timerColor.Tick += timerColor_Tick;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Cornsilk;
            ClientSize = new Size(984, 561);
            Controls.Add(labelMarquee);
            Controls.Add(label4);
            Controls.Add(label2);
            Controls.Add(comboBox1);
            Controls.Add(textBox1);
            Controls.Add(button1);
            Controls.Add(label1);
            Controls.Add(groupBox1);
            Name = "Form1";
            Text = "食物相剋系統";
            Load += Form1_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Button button1;
        private TextBox textBox1;
        private Label label2;
        private ComboBox comboBox1;
        private Label label4;
        private GroupBox groupBox1;
        private Label label3;
        private Label labelMarquee;
        private System.Windows.Forms.Timer timerScroll;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Timer timerColor;
        private Button button3;
        private Button button2;
    }
}
